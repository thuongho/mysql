Use a_emp;

/*  Demo 01 */	
select catg_id
 ,     sum(quantity_ordered)    as QuantitySold   
from   a_oe.order_details 
inner join a_prd.products  using(prod_id)
group by catg_id
;

/*  Demo 02 */
select sum(quantity_ordered) as QuantitySold   
from   a_oe.order_details 
join   a_prd.products  using(prod_id)
where catg_id = 'APL'
;

/*  Demo 03 */
select  
    sum(case when catg_id = 'APL' then quantity_ordered else null end) APL_QuantitySold        
from   a_oe.order_details 
join   a_prd.products  using(prod_id)
;
/*  Demo 04 */	
select  
    sum(case when catg_id = 'APL' then quantity_ordered else null end) APL_QuantitySold        
,   sum(case when catg_id = 'SPG' then quantity_ordered else null end) SPG_QuantitySold
,   sum(case when catg_id = 'HW ' then quantity_ordered else null end) HW_QuantitySold
,   sum(case when catg_id = 'PET' then quantity_ordered else null end) PET_QuantitySold
from   a_oe.order_details 
inner join a_prd.products  
on a_oe.order_details.prod_id= a_prd.products.prod_id
;



/*  Demo 05 */	
select   ord_id 
,   sum(case when catg_id = 'APL' then quantity_ordered else null end) AS APL_Quant
,   sum(case when catg_id = 'SPG' then quantity_ordered else null end) AS SPG_Quant
,   sum(case when catg_id = 'HW ' then quantity_ordered else null end) AS HW_Quant
,   sum(case when catg_id = 'PET' then quantity_ordered else null end) AS PET_Quant
from   a_oe.order_details 
inner join a_prd.products  
on a_oe.order_details.prod_id= a_prd.products.prod_id
group by ord_id
;

/*  Demo 06 */	
set @Mnth_1 := 10;
set @Mnth_2 := 11;
set @Mnth_3 := 12;

select   cust_id
, count(case when month(ord_date)= @Mnth_1  then 1 else null end) as "Month 1"
, count(case when month(ord_date)= @Mnth_2  then 1 else null end) as "Month 2"
, count(case when month(ord_date)= @Mnth_3  then 1 else null end) as "Month 3"
from     a_oe.order_headers
where    year(ord_date)= year(curDate()) -1
group by cust_id
order by cust_id;


/*  Demo 07 */	
select   
   sum(case when quoted_price between 0.01 and 25 
        then quantity_ordered 
        else 0 end)  as "Price 0.01-25"  
,  sum(case when quoted_price between 25.01 and 100 
        then quantity_ordered
        else 0 end)  as "Price 25.01-100"
,  sum(case when quoted_price between 100.01 and 250 
        then quantity_ordered
        else 0 end)  as "Price 100.01- 250"
,  sum(case when quoted_price >  250 
        then quantity_ordered
        else 0 end)  as "Price > 250"   
,  sum(quantity_ordered) as "Tot Quant"
from     a_oe.order_details
; 

/*  Demo 08 */	

select   
case
  when quoted_price between 0.01 and 25    then 'Price   0.01 -  25'
  when quoted_price between 25.01 and 100  then 'Price  25.01 - 100'
  when quoted_price between 100.01 and 250 then 'Price 100.01 - 250'
  when quoted_price >  250                 then 'Price over 250'
end as "Price Range"
,
sum(quantity_ordered) AS "Total Quantity"
from  a_oe.order_details
group by case
      when quoted_price between 0.01 and 25    then 'Price   0.01 -  25'
      when quoted_price between 25.01 and 100  then 'Price  25.01 - 100'
      when quoted_price between 100.01 and 250 then 'Price 100.01 - 250'
      when quoted_price >  250                 then 'Price over 250'
      end
order by 1
; 




/*  Demo 09  */	
Select PriceRange as "Price Range"
, sum(quantity_ordered) as "Total Quantity"
From (
   Select
     case
       when quoted_price between 0.01 and 25    then 'Cheap Price'
       when quoted_price between 25.01 and 100  then 'Low Price'
       when quoted_price between 100.01 and 250 then 'Medium Price'
       when quoted_price >  250                 then 'High Price'
     end as PriceRange
   , quantity_ordered
   From  a_oe.order_details
   )SalesAnalysis
Group by  PriceRange
Order by PriceRange
;


/*  Demo 10  */	
Select PriceRange as "Price Range"
, sum(quantity_ordered) as "Total Quantity"
From (
   Select
     case
       when quoted_price between 0.01 and 25    then 'Cheap Price'
       when quoted_price between 25.01 and 100  then 'Low Price'
       when quoted_price between 100.01 and 250 then 'Medium Price'
       when quoted_price >  250                 then 'High Price'
     end as PriceRange
   , quantity_ordered
   From  a_oe.order_details
   )SalesAnalysis
Group by  PriceRange
Order by  case PriceRange
   when 'Cheap Price'  then 1
   when 'Low Price'    then 2
   when 'Medium Price' then 3
   when 'High Price'   then 4
   end;






