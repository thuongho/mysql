
/*  Demo 01  */	
create table d_enum_01 ( 
  ord_id   int not null
, ord_mode varchar(15) not null
, constraint ord_mode_ck check (ord_mode in ('PHONE', 'ONLINE', 'DIRECT'))
)Engine = innodb;

Insert into d_enum_01 values (1, 'PHONE');
Insert into d_enum_01 values (2, 'INTERNET');

Select * from d_enum_01;

/*  Demo 02  */	
create table d_enum_02 ( 
  ord_id   int not null
, ord_mode enum('PHONE', 'ONLINE', 'DIRECT') 
)Engine = innodb;
Insert into d_enum_02 values (1, 'PHONE');
Insert into d_enum_02 values (2, 'INTERNET');
Insert into d_enum_02 values (3, 'DIRECT');

Select * from d_enum_02;


/*  Demo 03  */	
Update d_enum_02 set ord_mode = 'ONLINE' where ord_id = 3;
Update d_enum_02 set ord_mode = 'DOORTODOOR' where ord_id = 3;


/*  Demo 04  */	
Insert into d_enum_02 values (4, 'Phone');
Insert into d_enum_02 values (5, null);
Insert into d_enum_02 values (6, 'DIRECT');

Alter table d_enum_02 modify ord_mode enum('PHONE', 'ONLINE', 'DIRECT', 'DOORTODOOR');
Insert into d_enum_02 values (7, 'DOORTODOOR');

/*  Demo 05  */	
Select * from d_enum_02 
order by ord_mode;

select  'DIRECT' * 1;


/*  Demo 06  */	
Select ord_id, ord_mode, ord_mode * 1 
from d_enum_02;


/*  Demo 07  */	
Select * from d_enum_02 
order by cast(ord_mode as char);

Alter table d_enum_02 modify ord_mode enum('DIRECT', 'DOORTODOOR', 'ONLINE', 'PHONE');

Select ord_id, ord_mode, ord_mode * 1 from d_enum_02 order by ord_mode;

/*  Demo 08  */	
Select ord_id, ord_mode 
from d_enum_02
where ord_mode = 'PHONE';

Select ord_id, ord_mode 
from d_enum_02
where ord_mode = 3;


/*  Demo 09  */	
create table d_enum_03 ( 
  ord_id   int not null
, ord_mode enum('PHONE', 'ONLINE', 'DIRECT')  not null default 'DIRECT'
);

Insert into d_enum_03(ord_id) Values (33);
select * from d_enum_03;



/*  Demo 10  */	
create table d_enum_04 ( 
  ord_id   int not null
, ord_mode enum('PHONE', 'ONLINE', 'DIRECT')  not null
);

Insert into d_enum_04(ord_id) Values (44);
select * from d_enum_04;


/*  Demo 11  */	
  ord_id   int not null
, ord_mode varchar(15)  not null
);
Insert into d_enum_05(ord_id) Values (55);


/*  Demo 12  */	
Select sum(ord_mode) from d_enum_02;


 Select ord_mode, sqrt(ord_mode) from d_enum_02;

/*  Demo 13  */	
create table d_set_01( 
  emp_id int
, emp_cert SET ('Java','Visual Basic', 'C++','Database')
);


/*  Demo 14  */	
Insert into d_set_01 values (1, null);
Insert into d_set_01 values (2, 'Java');


Insert into d_set_01 values (3, 'Java,Database');

Insert into d_set_01 values (4, 'Database,Java');

Insert into d_set_01 values (5, 'Set Theory');

Insert into d_set_01 values (6, 'Database, Java');


/*  Demo 15  */	
select * from d_set_01;

/*  Demo 16  */	
Truncate d_set_01;
Insert into d_set_01 values (1, 'Java');
Insert into d_set_01 values (2, 'Visual Basic');
Insert into d_set_01 values (3, 'C++');
Insert into d_set_01 values (4, 'Database');


Insert into d_set_01 values (5, 'Java,Visual Basic' );
Insert into d_set_01 values (6, 'Java,C++'); 
Insert into d_set_01 values (7, 'Java,Database');


Insert into d_set_01 values (8, 'Visual Basic,C++');
Insert into d_set_01 values (9, 'Visual Basic,Database');
Insert into d_set_01 values (10, 'C++,Database');



Insert into d_set_01 values (11, 'Visual Basic,C++,Database');
Insert into d_set_01 values (12, 'Java,C++,Database');
Insert into d_set_01 values (13, 'Java,Visual Basic,Database');
Insert into d_set_01 values (13, 'Java,Visual Basic,C++');

Insert into d_set_01 values (14, 'Java,Visual Basic,C++,Database');



/*  Demo 17  */	
Select emp_id, emp_cert
, emp_cert *1 as Intgr
, lpad(bin(emp_cert*1),4,'0') as bnry 
from d_set_01 
order by bnry;


/*  Demo 18  */	
Select emp_id, emp_cert
, emp_cert *1 as Intgr
, lpad(bin(emp_cert*1),4,'0') as bnry 
from d_set_01 
where emp_cert like '%database%'
order by bnry;



/*  Demo 19  */	
Select emp_id, emp_cert
, emp_cert *1 as Intgr
, lpad(bin(emp_cert*1),4,'0') as bnry 
from d_set_01 
where emp_cert like '%Java%'
order by bnry;



/*  Demo 20  */	
Select emp_id, emp_cert
, emp_cert *1 as Intgr
, lpad(bin(emp_cert*1),4,'0') as bnry 
from d_set_01 
where emp_cert like '%Basic%'
order by bnry;

/*  Demo 21  */	
Select emp_id, emp_cert
, emp_cert *1 as Intgr
, lpad(bin(emp_cert*1),4,'0') as bnry 
from d_set_01 
where emp_cert like '%C++%'
order by bnry;

/*  Demo 22  */	
Select emp_id, emp_cert
from d_set_01 
where emp_cert = 'C++'




/*  Demo 23  */	
Select  column_name, column_type 
from information_schema.columns
Where table_schema='a_testbed' and table_name='d_enum_02';


/*  Demo 24  */	
Select  column_name, column_type 
from information_schema.columns
Where table_schema='a_testbed' and table_name='d_set_01';


/*  Demo 25  */	
Select  table_name, column_name, column_type 
from information_schema.columns
Where table_schema='a_testbed' and
Column_type like '%Basic%';


/*  Demo 26  */	
Select  table_name, column_name, column_type 
from information_schema.columns
Where table_schema='a_testbed' and
Column_type like '%Phone%';


/*  Demo 26  */	
Select  table_name, column_name, column_type 
from information_schema.columns
Where table_schema='a_testbed' and
Column_type like 'enum(%';


