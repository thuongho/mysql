Delimiter #

-- Demo 01:	
Select newsalary_1 (4500) as Result #
Select newsalary_1 (null) as Result #
Select newsalary_1 (-4500) as Result #
-- Demo 02:	
Drop function if exists newsalary_1_V2#

create function newsalary_1_V2 (
   in_salary   decimal(9,2))
   returns decimal(10,2) 
begin
   declare  c_increase_amount decimal (8,2) default 300;
   declare  v_new_salary      decimal (8,2);

 
   if in_salary is null then
      set v_new_salary  := c_increase_amount;
   elseif in_salary < 0 then
      set v_new_salary  := 0;
   else
      set v_new_salary  := in_salary + c_increase_amount;
   end if;

   return v_new_salary ;
end;
#



-- Demo 03:	
select 
  Salary
, AnticipatedValue
, newsalary_1_V2 (salary) as "new salary"
, AnticipatedValue - NewSalary_1_v2(salary) as "problem"
from (
    select 10000 as Salary
         , 10300 as AnticipatedValue 
  union all  
    select null,   300
  union all  
    select -500,  0
) as tstTbl#


Select 
   newsalary_1_V2 (4500) as Result_1
,  newsalary_1_V2 (null) as Result_2
,  newsalary_1_V2 (-35)  as Result3#


-- Demo 04:	
drop function if exists a_testbed.FutureDate#

create  function a_testbed.FutureDate (
  p_date  datetime
, p_yr  int
, p_mn  int
, p_day  int)
  returns date
BEGIN
    declare return_date date ;
	set return_date := p_date;

    set p_yr  :=coalesce(p_yr,  0);
    set p_mn  :=coalesce(p_mn,  0);
    set p_day :=coalesce(p_day, 0);

    set return_date := date_add(return_date, interval p_yr year);
    set return_date := date_add(return_date, interval p_mn month);
    set return_date := date_add(return_date, interval p_day day);

    return return_date;
    end;
#


select a_testbed.FutureDate(current_date,4,5,-2)#
-- demo 05

drop function if exists a_testbed.FutureDate2#


create function a_testbed.FutureDate2 (
  p_date  datetime
, p_y  int
, p_m  int
, p_d  int)
  returns date
BEGIN
 return p_date + interval coalesce(p_y, 0) year + interval coalesce(p_m, 0) month + interval coalesce(p_d, 0) day;
    end;
#

--demo 06

Drop function if exists DeptEmployeeCount #

Create function DeptEmployeeCount  (
   p_dept_id int)
   returns int
begin
    declare  v_row_count   int ;
    select   count(*)
    into     v_row_count
    from     a_emp.employees
    where    Dept_id = p_dept_id;
    
    return v_row_count;
end;
#
-- demo 07
select DeptEmployeeCount (80) 
#
select DeptEmployeeCount (1234) 
#


-- demo 08
Drop function if exists empjobtitle# 

create function empjobtitle
   (in_emp_id int) 
   returns varchar(100)
begin
   declare  v_job_title  varchar(35);
   declare  v_message    varchar(100);

   select   job_title
     into   v_job_title
     from   a_emp.employees join a_emp.jobs using (job_id)
     where  emp_id = in_emp_id;
  set  v_message := concat('employee ' , in_emp_id ,' has job ' , v_job_title);
   return v_message;
end; 
#

-- demo 09
select  EmpJobTitle(103)#
-- demo 10
select  EmpJobTitle(63) #


