use a_vets;

Select an_id, an_name  
From a_vets.vt_animals
Where an_type in ( 'cat', 'dog');


/*  Demo 01  */	
select an_id, an_name 
from  a_vets.vt_animals
where an_type = 'cat'
UNION
select an_id, an_name 
from  a_vets.vt_animals
where an_type = 'dog';



/*  Demo 02  */	
select an_id, an_name 
from  a_vets.vt_animals
where an_type = 'cat'
UNION
select an_id, an_dob
from  a_vets.vt_animals
where an_type = 'dog';


/*  Demo 03  */	
select an_id, an_name  
from  a_vets.vt_animals
where an_type = 'cat'
UNION
select an_id, cast(an_dob as char(10))  
from  a_vets.vt_animals
where an_type = 'dog';



use a_oe;

/*  Demo 04  */	
select   ord_id, prod_id, catg_id, prod_name
from     a_oe.order_details 
join     a_prd.products using (prod_id) 
where    catg_id in ('PET', 'SPG')
order by ord_id
;


/*  Demo 05  */	
   select   ord_id, prod_id, catg_id, prod_name
   from     a_prd.products  join a_oe.order_details 
            using (prod_id)
   where    catg_id = 'PET' 
UNION ALL
   select   ord_id, prod_id, catg_id, prod_name
   from     a_prd.products join a_oe.order_details 
            using (prod_id)
   where    catg_id = 'SPG' 
order by ord_id
;



/* /*  Demo 06  */	
   select   ord_id, prod_id, catg_id, prod_name
   from     a_prd.products join a_oe.order_details using (prod_id)
   where    catg_id = 'PET' 
UNION ALL
   select   ord_id, prod_id
   from     a_prd.products join a_oe.order_details using (prod_id)
   where    catg_id = 'SPG' 
order by ord_id
;

*/

/*  Demo 07  */	
   select   name_last, name_first, 'Employee' as "Pers Type"
   from     a_emp.employees
UNION ALL
   select   cust_name_last, cust_name_first, 'Customers'
   from     a_oe.customers
;



/*  Demo 08  */	
   select   prod_id, catg_id, prod_name
   from     a_prd.products
   join     a_oe.order_details using (prod_id)
   join     a_oe.order_headers  using (ord_id)
   where    catg_id = 'HW' 
   and      extract(month from ord_date) = 11 
UNION ALL
   select   prod_id, catg_id, prod_name
   from     a_prd.products
   join     a_oe.order_details using (prod_id)
   join     a_oe.order_headers  using (ord_id)
   where    catg_id = 'HW' 
   and      extract(month from ord_date) = 12 
order by prod_id
;


/*  Demo 09  */	
   select   prod_id, catg_id, prod_name
   from     a_prd.products
   join     a_oe.order_details using (prod_id)
   join     a_oe.order_headers  using (ord_id)
   where    catg_id = 'HW' 
   and      extract(month from ord_date) = 11 
UNION 
   select   prod_id, catg_id, prod_name
   from     a_prd.products
   join     a_oe.order_details using (prod_id)
   join     a_oe.order_headers  using (ord_id)
   where    catg_id = 'HW' 
   and      extract(month from ord_date) = 12 
;

/*  Demo 10  */	
   select  prod_id  AS "Product ID"
   ,       prod_list_price as "List Price"
   from    a_prd.products
   where   catg_id = 'APL'
UNION  ALL
   select  '---- Avg Price for all Appliances ----'
   ,       Avg(prod_list_price)
   from    a_prd.products
   where   catg_id = 'APL' 
;


/*  Demo 11  */	
use a_testbed;

Create table d_set_emp ( E_id int, E_name varchar(10), E_city varchar(10));

Create table d_set_cust ( C_id int, C_name varchar(10), C_city varchar(10));
Insert into d_set_emp values ( 101, 'Jones',     'Chicago');
Insert into d_set_emp values ( 102, 'Anderson',  'Chicago');
Insert into d_set_emp values ( 103, 'Baxter',    'Chicago');
Insert into d_set_emp values ( 104, 'Johnson',   'Chicago');
Insert into d_set_emp values ( 105, 'Miller',    'Chicago');

Insert into d_set_cust values ( 201, 'Oliver',   'Boston');
Insert into d_set_cust values ( 202, 'Athena',   'Boston');
Insert into d_set_cust values ( 203, 'Sanders',  'Boston');
Insert into d_set_cust values ( 204, 'Baxter',   'Boston');

/*  Demo 12  */	
Select E_id, E_name, E_city from d_set_emp
Union all
Select C_id, C_name, C_city from d_set_cust;


/*  Demo 13  */	
Select E_id, E_name, E_city from d_set_emp
Union all
Select C_id, C_name, C_city from d_set_cust
Order by E_name;



/*  Demo 14  */	
(Select E_id, E_name, E_city from d_set_emp Order by E_name)
Union all
(Select C_id, C_name, C_city from d_set_cust order by c_name)
;



/*  Demo 15  */	
(Select E_id, E_name, E_city from d_set_emp  order by E_name Limit 2)
Union all
(Select C_id, C_name, C_city from d_set_cust order by c_name Limit 2)
;


/*  Demo 16  */	
(Select E_id, E_name, E_city from d_set_emp Order by E_name Limit 200)
Union all
(Select C_id, C_name, C_city from d_set_cust order by c_name Limit 200)
;



