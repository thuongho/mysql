Use a_emp;

/*  Demo 01 */	
select    dept_id
from      a_emp.employees
;

/*  Demo 02 */	
select    dept_id
from      a_emp.employees
group by  dept_id
;

/*  Demo 03 */	
select    dept_id, emp_id
from      a_emp.employees
group by  dept_id
;

/*  Demo 04 */	
select    dept_id, job_id
from      a_emp.employees
group by  dept_id, job_id
;

/*  Demo 05 */	
select    dept_id, job_id
from      a_emp.employees
group by  job_id, dept_id
;

/*  Demo 06 */	
select    dept_id, job_id
from      a_emp.employees
group by  job_id, dept_id
order by dept_id, emp_id
;


/*  Demo 07 */	
select    dept_id
,         COUNT(*)
,         AVG(salary)
from      a_emp.employees
group by  dept_id
;

/*  Demo 08 */	
select   catg_id     
,        AVG(prod_list_price) as "Avg List Price"
,        MAX(prod_list_price) as "Max List Price"
from     a_prd.products
group by catg_id
;

/*  Demo 09 */	
select   dept_id, job_id
,        COUNT(*) AS NumEmployee
,        AVG(salary) AS AvgSalary
from     a_emp.employees
group by dept_id, job_id
order by AVG(salary)
;

/*  Demo 10 */	
select   COUNT(*) AS NumEmployee
,        AVG(salary) AS AvgSalary
from     a_emp.employees
group by dept_id, job_id
order by AVG(salary)
;

/*  Demo 11 */	
select catg_id,   MAX(prod_list_price) as MaxPrice
from      a_prd.products
group by catg_id 
;

/*  Demo 12 */	
select p.catg_id, p.prod_id,  p.prod_list_price,p.prod_desc 
from a_prd.products  P
where  (p.catg_id,p.prod_list_price)
in (select catg_id,   MAX(prod_list_price) as MaxPrice
    from      a_prd.products
    group by catg_id );

/*  Demo 13 */	
select   dept_id
,        COUNT(*)
,        AVG(salary)
from     a_emp.employees
group by dept_id
;

/*  Demo 14 */	
select   dept_id
,        count(*)
,        avg(salary)
from     a_emp.employees
group by dept_id
having   avg(salary) > 30000
;

/*  Demo 15 */	
select   dept_id
,        count(*)
,        avg(salary)
from     a_emp.employees
where    dept_id between 30 and 40
group by dept_id
having   avg(salary) > 30000
;

/*  Demo 16 */	
select   dept_id
,        COUNT(*)
,        AVG(salary)
from     a_emp.employees
where    salary > 30000
group by dept_id
;


/*  Demo 17 */	
select   dept_id
,        COUNT(*)
,        AVG(salary)
from     a_emp.employees
group by dept_id
having   COUNT(*) > 3 
;

/*  Demo 18 */	
select   name_last    As DuplicateName
,        COUNT(*)
from     a_emp.employees
group by name_last    
having   COUNT(*) > 1;

/*  Demo 19 */	
select   ord_id
,        count(*) AS "NumberLineItems"
from     a_oe.order_headers  inner join 
         a_oe.order_details using (ord_id)  
group by ord_id
order by ord_id
;


/*  Demo 20 */	
select   cust_id
,        ord_id
,        shipping_mode
,        count(*) AS "NumberLineItems"
from     a_oe.order_headers  inner join 
         a_oe.order_details using (ord_id)  
group by ord_id
order by cust_id, ord_id
;

/*  Demo 20 alt */	
select   cust_id
,        ord_id
,        shipping_mode
,        count(*) AS "NumberLineItems"
from     a_oe.order_headers  inner join 
         a_oe.order_details using (ord_id)  
group by ord_id, cust_id, shipping_mode
order by cust_id, ord_id
;


/*  Demo 21 */	
select   cust_id, cust_name_last, ord_id
,        cast(ord_date as date) as OrderDate
,        sum( quantity_ordered * quoted_price) as amntdue
from     a_oe.customers inner join 
         a_oe.order_headers  using (cust_id) inner join 
         a_oe.order_details using (ord_id)  
group by ord_id, cust_id, cust_name_last, ord_date
order by cust_id, ord_id
;



/*  Demo 22	 */	
select  count(*) as "NumProducts"
,       count(prod_warranty_period) as "NumWithWarranty"
from    a_prd.products
;

/*  Demo 23 */	
select   prod_warranty_period ,  count(*) as "NumProducts"
from     a_prd.products 
group by prod_warranty_period
order by  prod_warranty_period 
;

/*  Demo 24 */	
select   coalesce( (prod_warranty_period), 'no warranty') as "Warranty"
,        count(*) as "NumProducts"
from     a_prd.products
group by prod_warranty_period
order by prod_warranty_period 
;



/*  Demo 25 */	
use a_testbed;
create table z_aggs (id integer, fee decimal(5,2));
  insert into z_aggs values (1, 45);
  insert into z_aggs values (2, 0);
  insert into z_aggs values (3, null);  
  insert into z_aggs values (4, null);   


select count(*), count(id), count(fee), sum(fee), avg(fee), max(fee)
from z_aggs;


select count(*), count(fee) , max(fee)
from z_aggs
group by fee;
