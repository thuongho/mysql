
-- Demo 01:	
select   AVG( prod_list_price)as avgprice
from     a_prd.products  
;



-- Demo 02:	
select   prod_id, prod_list_price, catg_id
from     a_prd.products  
where    prod_list_price >( 
     select   AVG( prod_list_price)
     from     a_prd.products  )
;


-- Demo 03:	
select   AVG( prod_list_price)as avgPrice, catg_id
from     a_prd.products  
group by catg_id
;


-- Demo 04:	
select   prod_id, catg_id, prod_list_price
from     a_prd.products    Otr
where    prod_list_price >(
     select   AVG(prod_list_price)
     from     a_prd.products    Inr
     where    Otr.catg_id = Inr.catg_id )
order by catg_id, prod_list_price
; 

-- Demo 05:	
CREATE OR REPLACE VIEW a_oe.OE_OrdExtTotal AS   
    select   ord.cust_id
    ,        ord.ord_id 
    ,        SUM(odt.Quantity_ordered * odt.quoted_price)AS ordertotal
    from     a_oe.order_headers ord
    join     a_oe.order_details odt on ord.ord_id = odt.ord_id
    group by ord.cust_id, ord.ord_id
; 


-- Demo 06:	
select   cust_id
,        round( AVG(ordertotal), 2)  frm_avg
,        1.25 * round(AVG(ordertotal),2 )  cut_off
from     a_oe.OE_OrdExtTotal
group by cust_id
;


-- Demo 07:	
select   cust_id
,        ord_id
,        ordertotal
from     a_oe.OE_OrdExtTotal  OTR
where    OrderTotal > 1.25 * (
     select   round( AVG(ordertotal), 2)  
     from     a_oe.OE_OrdExtTotal    INR
     where    OTR.Cust_id = INR.Cust_id
     group by cust_id)
; 


-- Demo 08:	
select   cust_id
,        cust_name_last
from     a_oe.customers  C
where    1 < (
     select   COUNT( *)
     from     a_oe.order_headers 
     where    cust_id = C.cust_id )
;
-- demo 09
Select cust_id, cust_name_last
 , Case ( 
        select count(*) 
        from a_oe.order_headers OH 
        where OH.cust_id = CS.cust_id)
   when 0 then '. . . No orders'     
   when 1 then '1 order'    
   when 2 then '2 orders'
   when 3 then '3 orders'    
   else  '4+ orders'          
   End as NumberOfOrders
From a_oe.customers  CS ;
