
-- Demo 01:	
select CS.cust_name_last, CS.cust_name_first
from   a_oe.customers      CS
join   a_oe.order_headers  OH on CS.cust_id = OH.cust_id
order by CS.cust_name_last, CS.cust_name_first
;

-- Demo 02:	
select distinct CS.cust_name_last, CS.cust_name_first
from   a_oe.customers      CS
join   a_oe.order_headers  OH on CS.cust_id = OH.cust_id
order by cust_name_last, cust_name_first
;

-- Demo 03:	
select distinct CS.cust_name_last, CS.cust_name_first, CS.cust_id
from   a_oe.customers      CS
join   a_oe.order_headers  OH on CS.cust_id = OH.cust_id
order by cust_name_last, cust_name_first
; 

-- Demo 04:	
Select   cust_name_last, cust_name_first
 from (
   select distinct CS.cust_name_last, CS.cust_name_first, CS.cust_id
   from   a_oe.customers      CS
   join   a_oe.order_headers  OH on CS.cust_id = OH.cust_id
) CS
; 

-- Demo 05:	
select cust_name_last, cust_name_first
from   a_oe.customers CS
where  cust_id in 
   (select cust_id 
    from a_oe.order_headers )
;

-- Demo 06:	
select 
  dept_id
, dept_name
, loc_type  as LocationType
from a_emp.departments D 
left join a_emp.locations   L on D.loc_id = L.loc_id
order by dept_id
;

-- Demo 07:	
select 
  dept_id
, l.loc_id
, loc_type as LocationType
, loc_city as City
, loc_state_province as "State/Province"
from a_emp.departments D 
left join a_emp.locations   L on D.loc_id = L.loc_id
order by dept_id
;

-- Demo 08:	
select 
  dept_id
, coalesce(loc_type, 'Unknown type') as LocationType
, coalesce(loc_city, 'No Site') as City
, coalesce(loc_state_province, 'No Site') as "State/Province"
from a_emp.departments D 
left join a_emp.locations   L on D.loc_id = L.loc_id
order by dept_id
;

-- Demo 09:	
select 
  dept_id
, coalesce(loc_type, 'No Site') as LocationType
, coalesce(loc_city, 'No Site') as City
, coalesce(loc_state_province, 'No Site') as "State/Province"
from  a_emp.departments D 
left join ( 
   select loc_id
   ,  coalesce(loc_type, 'UnknownType') as loc_type
   , loc_city, loc_state_province 
   from a_emp.locations) L  on  D.loc_id = L.loc_id
  order by dept_id
;



