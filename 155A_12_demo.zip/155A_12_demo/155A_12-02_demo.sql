use a_testbed;

-- Demo 01	
DROP TABLE if exists ddl_emp_proj ;
DROP TABLE if exists ddl_proj ;
DROP TABLE if exists ddl_emp ;
DROP TABLE if exists ddl_dept ;


-- Demo 02	
drop table  if exists ddl_dept2 ;
CREATE TABLE ddl_dept2 
( 
   d_id     numeric(3) 
 , d_name   varchar(15)
) engine=InnoDB;


-- Demo 03
insert into ddl_dept2 (d_id, d_name)
values(10,'Sales');

-- Demo 04
insert into ddl_dept2 (d_id, d_name)
values(null,null);

-- Demo 05
insert into ddl_dept2 (d_id, d_name)
values(10,'Marketing');

-- Demo 06
Insert into ddl_dept2 (d_id, d_name)
values(40.8,'Development');


-- Demo 07
insert into ddl_dept2 (d_id, d_name)
values(-44,'');


-- Demo 08
insert into ddl_dept2 (d_id, d_name)
values(1234,'Research');


-- Demo 09
Insert into ddl_dept2 (d_id, d_name)
values(20,'Accounting and Payroll');


-- Demo 10
insert into ddl_dept2 (d_id, d_name)
values(35);


-- Demo 11
insert into ddl_dept2 (d_id)
values(35);


Select * from ddl_dept2 order by d_id ;

Drop table ddl_dept2;

-- Demo 12	
CREATE TABLE  ddl_proj 
(
   p_id   varchar(10)    
 , p_name varchar(15)    null
 , constraint  ddl_proj_PK  primary key(p_id)
 , constraint ddl_proj_P_Name_UN   unique(p_name)
) engine=InnoDB;



-- Demo 13
CREATE TABLE  ddl_dept 
( 
    d_id     numeric(3)      
 ,  d_name   varchar(15) not null
 ,  constraint ddl_dept_PK          primary key(d_id)
 ,  constraint ddl_dept_D_Name_UN   unique(d_name)
) engine=InnoDB;


-- Demo 14
create table ddl_un (id numeric(3)
, city varchar(15), state char(2)
, constraint location_UN  unique(city, state)
) engine=InnoDB;

Insert into ddl_un (id, city, state) values (1, 'Chicago', 'IL');
Insert into ddl_un (id, city, state) values (2, 'Chicago', 'CA');
Insert into ddl_un (id, city, state) values (3, 'Pekin', 'IL');

-- fails
Insert into ddl_un (id, city, state) values (4, 'Pekin', 'IL');

Insert into ddl_un (id, city, state) values (5, null, null);
Insert into ddl_un (id, city, state) values (6, null, null);


select * from ddl_un;

drop table ddl_un;


-- Demo 15
CREATE TABLE  ddl_emp 
( 
  e_id    numeric(3)    
, e_name  varchar(15) not null
, d_id    numeric(3)  not null 
, constraint ddl_emp_pk  primary key(e_id)
, constraint ddl_emp_dept_fk foreign key (d_id) references ddl_dept(d_id)
) engine=InnoDB;


-- Demo 16
show create table ddl_emp\G
			  

-- demo 17
CREATE TABLE  ddl_emp_proj 
( 
  p_id  varchar(10) not null 
, constraint ddl_emp_proj_proj_fk foreign key(p_id) references ddl_proj( p_id)
, e_id  numeric(3)  not null
, constraint ddl_emp_proj_emp_fk foreign key (e_id)references ddl_emp(e_id)
, constraint  ddl_empproj_pk   primary key ( p_id, e_id)
) engine=InnoDB;


-- demo 18
CREATE TABLE  ddl_parent (p_id numeric(3) primary key) engine=InnoDB;
CREATE TABLE  ddl_child  (c_id numeric(3) primary key
                        , fk_id numeric(3) 
                        , foreign key(fk_id) references ddl_parent(p_id) 
                          on delete cascade) engine=InnoDB;

Insert into ddl_parent(p_id) values (1);
Insert into ddl_parent(p_id) values (2);
Insert into ddl_parent(p_id) values (3);

Insert into ddl_child(c_id, fk_id) values (100,2);
Insert into ddl_child(c_id, fk_id) values (101,2);
Insert into ddl_child(c_id, fk_id) values (103,2);
Insert into ddl_child(c_id, fk_id) values (104,3);

Select p_id, c_id, fk_id 
from ddl_parent 
join ddl_child on ddl_parent.p_id = ddl_child.fk_id;

-- demo 19
Delete from ddl_parent where p_id = 2;
Select * from ddl_parent;
Select * from ddl_child;

-- demo 20
Drop TABLE  ddl_child ; 
CREATE TABLE  ddl_child  (c_id numeric(3) primary key
                        , fk_id numeric(3) 
                        , foreign key(fk_id) references ddl_parent(p_id) 
                          on delete set null) engine=InnoDB;

Insert into ddl_parent(p_id) values (2);
Insert into ddl_child(c_id, fk_id) values (100,2);
Insert into ddl_child(c_id, fk_id) values (101,2);
Insert into ddl_child(c_id, fk_id) values (103,2);
Insert into ddl_child(c_id, fk_id) values (104,3);

Delete from ddl_parent where p_id = 2;

Select * from ddl_child;

Drop TABLE  ddl_child ; 
Drop TABLE  ddl_parent ; 


-- demo 21
Create table ddl_default ( 
    id numeric(3)
  , d_state char(2) default 'CA'
)engine=InnoDB;

Insert into ddl_default (id, d_state) values (1, 'PA');
Insert into ddl_default (id, d_state) values (2, 'CA');
Insert into ddl_default (id, d_state) values (3, default);
Insert into ddl_default (id)          values (4);
Select * from ddl_default;


Drop table ddl_default;


-- demo 22
Create table ddl_check ( 
    id numeric(3)
  , d_state char(2) 
  , constraint dstated_ck  
                    check(d_state in ('CA','NV','IL'))
)engine=InnoDB;

Insert into ddl_check (id, d_state) values (1, 'CA');
Insert into ddl_check (id, d_state) values (2, 'IL');

-- this should fail but doesn't
Insert into ddl_check (id, d_state) values (3, 'NY');



Insert into ddl_check (id, d_state) values (4, null);
select * from ddl_check;   


show create table ddl_check\G

Drop table ddl_check;

-- demo 23
Create table ddl_check ( 
    id numeric(3)
  , weight numeric (3)  
  , constraint weight_ck  
                    check(weight between 0 and 500)
) engine=InnoDB;
Insert into ddl_check values (1, 450);
Insert into ddl_check values (2, 950);

Drop table ddl_check;


-- demo 24
CREATE TABLE  ddl_dept_2 
 ( 
    d_id    numeric(3)  primary key
  , d_name  varchar(15) not null
  , d_city  varchar(15) not null
  , d_state char(2)      
  , d_phone varchar(10) 
  , constraint dphone2_un  unique(d_phone)
  , constraint  dlocation2_un unique( d_name, d_city, d_state) 
 ) engine=InnoDB;

 
 -- demo 25
 CREATE TABLE ddl_emp_2 
 (
    e_id     numeric(3)
  , e_name   varchar(15)      not null
  , d_id     numeric(3)
  , salary   numeric(5)         
             default 30000
  , hiredate date              
  , startsalary numeric(5)      
  , constraint emp2_pk  primary key (e_id )
  , constraint emp2_dept2_fk foreign key (d_id) references ddl_dept_2(d_id)
) engine=InnoDB;


-- demo 26
Drop table ddl_dept;
 

