use a_testbed;

-- demo 01
drop table if exists  ac_emp; 
drop table if exists  ac_dept; 

-- demo 02
create table  ac_dept  ( 
   d_id     numeric(3)    
 , constraint ac_dept_pk   primary key(d_id) 
 , d_name   varchar(15) not null  
 , d_budget numeric (6) null
 , d_expenses_to_date numeric (6) null
 , d_city   varchar(15) not null
 , d_state  char(2)  not null    
 , constraint  ac_dlocation_un unique( d_name, d_city, d_state) 
) ENGINE=InnoDB;


create table ac_emp  (
   e_id     numeric(3) 
 , e_name   varchar(15)   not null 
 , d_id     numeric(3)    null
 , salary   numeric(5)    unsigned
            default 30000 null
, hiredate date null        
, e_status char (4)  null    
, constraint ac_emp_pk  primary key (e_id ) 
, constraint ac_emp_dept_fk foreign key(d_id)  references ac_dept(d_id) 
) ENGINE=InnoDB;


-- demo 03
insert into ac_dept (d_name, d_id, d_city,d_state, d_budget,d_expenses_to_date)
values  ('FINANCE', 301, 'PEKIN', 'IL',     50000,     15000);
			
insert into ac_dept (d_id,d_budget,d_expenses_to_date,d_name,d_city,d_state)
values  (501,  15000, 16000,  'SALES', 'RENO',  'NV');

-- Demo 04
insert into ac_dept 
values ( 201, 'SALES', 35000, null, 'CHICAGO', 'IL');

-- Demo 05
insert into ac_dept (d_name,  d_id, d_city, d_state )
values  ('ADMIN', 401, 'CHICAGO', 'IL') ;
 
 
 
-- demo 06
insert into ac_emp (e_id, e_name, d_id, salary, hiredate, e_status) 
values( 10, 'FREUD', 301, DEFAULT, '2002-06-06', 'PERM');

-- demo 07
insert into ac_emp (e_id, e_name, d_id,  e_status) 
values( 20, 'MATSON', 201, 'PERM');


-- Demo 08:		 
insert into ac_emp (e_id, e_name, d_id, salary, hiredate, e_status) 
values
  ( 30, 'HANSON', 201, 40000, '2003-05-15', 'PERM')
, ( 40, 'IBSEN',  201, 45000, '2003-05-20', 'PERM')
, ( 50, 'MILES',  401, 25000, '2003-06-20', 'PERM')
, ( 60, 'TANG',   401, 25000, '2003-06-20', null)
, ( 70, 'KREMER', 501, 50000, '2003-07-15', null)
, ( 80, 'PAERT',  201, 65000, '2003-07-18', null)
, ( 90, 'JARRET', 301, 60000, '2003-08-08', null);

-- demo 09
insert into ac_dept (d_name,   d_id, d_city, d_state, d_budget)
            values  ('FINANCE', 304, NULL, 'NY', 25000);
insert into ac_dept (d_name,   d_id, d_city, d_state, d_budget)
            values  ('SALES',  305, 'CHICAGO', 'IL', 45000);

insert into ac_emp  (e_id, e_name, d_id,  e_status) 
            values  ( 99, 'MATSON', 210, 'PERM');
insert into ac_emp  (e_id, e_name, d_id,  e_status) 
            values  ( 98, 'Mathewsohn-Maryville', 201, 'PERM');

select  * from  ac_dept;
select  * from  ac_emp;

-- demo 10
insert into ac_dept
   SET d_name = 'Research'
   ,   d_id = 800
   ,   d_city = 'San Francisco'
   ,   d_state = 'CA'
   ,   d_budget = 98000;   
   
   
-- demo 11
Create table ac_potentialhire (  e_id numeric(3)
, e_name varchar(15) not null
, d_id numeric(3)
, salary numeric(5) unsigned
, hiredate date
, e_status char (4)
) ENGINE=InnoDB;

truncate table ac_potentialhire ;


insert into ac_potentialhire (e_id, e_name, d_id, salary, hiredate, e_status) 
             values( 201, 'ROBYN', 301, 20000, '2009-09-15', 'TEMP');
insert into ac_potentialhire (e_id, e_name, d_id, salary, hiredate, e_status) 
             values( 202, 'ECHART', 201, 20000, null, 'TEMP');
insert into ac_potentialhire (e_id, e_name, d_id, salary, hiredate, e_status) 
             values( 203, 'TATUM', 301, 25000, '2009-09-18', 'TEMP');
-- demo 12
insert into  ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
    select   e_id, e_name, d_id, salary, hiredate, e_status
    from     ac_potentialhire
    where    hiredate is not null;

-- demo 13
delete   
from   ac_potentialhire
where  hiredate is not null;

select  * from  ac_emp;
select * from ac_potentialhire;

-- demo 14
delete 
from    ac_emp 
where   d_id = 601;

-- demo 15
delete 
from    ac_emp
where   d_id in (
         select   d_id
         from     ac_dept
         where    d_state = 'NV');
		 
-- demo 16
update  ac_emp
set     e_status = 'TEMP';

-- demo 17
update  ac_emp
set     e_status  = 'PERM'
where   hiredate < '2003-07-01';

-- demo 18
update  ac_dept
set     d_city   = 'SAN FRANCISCO', 
        d_state = 'CA'
where   d_id = 401;

-- demo 19
update  ac_emp
set     salary = salary * 1.1
where   e_status = 'PERM';

-- demo 20
update  ac_emp
set     salary =  salary * ( 1 + case 
                    when salary < 40000 then 0.25
                    when salary < 50000 then 0.10
                    else  0.05  end  ) ; 
-- demo 21	
update  ac_emp
set     salary = salary * 1.1
where   d_id in 
         (select   d_id
          from     ac_dept
          where    d_state = 'CA');

-- demo 22	
select d_city, d_state, e_name, salary
from ac_dept
join ac_emp on ac_dept.d_id = ac_emp.d_id
order by d_state, d_city ;


set @city = 'CHICAGO';
set @state = 'IL';
set @wageDifferential= 1.25;

update  ac_emp
set     salary = salary * @wageDifferential
where   d_id in 
         (select   d_id
          from     ac_dept
          where    d_state = @state and d_city = @city);

select d_city, d_state, e_name, salary
from ac_dept
join ac_emp on ac_dept.d_id = ac_emp.d_id
order by d_state, d_city ;

-- demo 23	
update ac_dept
set
   d_budget = d_budget - d_expenses_to_date
 , d_expenses_to_date = null;
 
select d_id, d_budget, d_expenses_to_date from ac_dept;
 
-- demo 24
update ac_dept
set
   d_budget = case  
         when d_budget > coalesce(d_expenses_to_date,0) then d_budget - coalesce(d_expenses_to_date,0)
         else  0
         end
 , d_expenses_to_date = case  
         when d_budget > coalesce(d_expenses_to_date,0) then 0
         else coalesce(d_expenses_to_date,0)- d_budget         
         end
 where d_budget is not null;
 
select d_id, d_budget, d_expenses_to_date 
from ac_dept;

-- demo 25
update ac_dept
set   d_budget = rand() * coalesce(d_budget, 500);

select d_id, d_budget, d_expenses_to_date from ac_dept;
 
 -- demo 26
update   ac_dept
set      d_budget = null;					

-- ------------------------------------------------------------
-- demo 27
create table  ac_emp_d201 as
    select * 
    from   ac_emp
    where  d_id = 201;

select  * from  ac_emp_d201;

-- demo 28
create table   ac_emp_il  as
    select  e_name, salary, d_city, d_state  
    from    ac_dept, ac_emp
    where   ac_dept.d_id = ac_emp.d_id
    and     d_state = 'IL'; 



-- demo 29
create table ac_potentialhire_2 as  
    select   * 
    from     ac_emp
    where    1=2; 


 show create table ac_potentialhire_2\G

