use a_testbed;

-- demo 01
create table ac_projects (
 prj_id int primary key,
 prj_name varchar(20),
 prj_budget int
 );

Insert into ac_projects (prj_id, prj_name) values
  ( 10, 'Snowball' )
, ( 20, 'Frosting')
, ( 30, 'Sphinx' )
, ( 40, 'Kilimanjaro'  )
;
select * from ac_projects;

-- demo 02
insert into ac_projects 
values  (20, 'Icing', 450000);


-- demo 03
insert into ac_projects 
values  (20, 'Icing', 450000)
on duplicate key update
  prj_name  = 'Icing'
, prj_budget = 450000
;

select * from ac_projects;

-- demo 04
insert into ac_projects (prj_name, prj_id, prj_budget)
values  ('cupcake', 42, 12000)
on duplicate key update
  prj_name = 'cupcake'
, prj_budget = 50000
;
select * from ac_projects;

-- demo 05
insert into ac_projects (prj_name, prj_id, prj_budget)
values  ('Catapult', 50, 586000)
on duplicate key update
  prj_name = values(prj_name)
, prj_budget = values(prj_budget)
;

insert into ac_projects (prj_name, prj_id, prj_budget)
values  ('Crescent', 30, 4000)
on duplicate key update
  prj_name = values(prj_name)
, prj_budget = values(prj_budget)
;

-- demo 06
insert into ac_projects (prj_name, prj_id, prj_budget)
values  ('Crescent', 30, 2500)
on duplicate key update
  prj_name = values(prj_name)
, prj_budget =greatest( ac_projects.prj_budget, values(prj_budget))
;
select * from ac_projects;

insert into ac_projects (prj_name, prj_id, prj_budget)
values  ('Crescent', 30, 7500)
on duplicate key update
  prj_name = values(prj_name)
, prj_budget =greatest( ac_projects.prj_budget, values(prj_budget))
;
select * from ac_projects;
  
-- demo 07
insert into ac_projects (prj_name, prj_id, prj_budget) 
values  
  ('Godot',     101,   50001)
, ('Milan',     102,   50002)
, ('Omega',     030,  125000)
, ('Palladium', 050,   50003)
, ('Greenwich', 103,   50004)
, ('Deco',      040,   50005)
, ('Volta',     042,   50005)
on duplicate key update
  prj_name   = values(prj_name)
, prj_budget = greatest( ac_projects.prj_budget, values(prj_budget))
;
select * from ac_projects;

-- Demo 08
insert into ac_projects (prj_name, prj_id, prj_budget)
values  ('Volta', 042, null)
on duplicate key update
 prj_budget = ac_projects.prj_budget * 1.5
;

insert into ac_projects (prj_name, prj_id, prj_budget)
values  ('Volta', 043, null)
on duplicate key update
 prj_budget = ac_projects.prj_budget * 1.5
;



-- demo
Create table NewData (
 nd_id int primary key,
 nd_name varchar(20),
 nd_budget int
 );

 
 Insert into NewData (nd_id, nd_name, nd_budget) values
  ( 267, 'Koko' , 400)
, ( 268, 'Martinville', 4500)
, (  30, 'Alpha', 400 )
, (  40, 'Deco', 345  )
;

insert into ac_projects ( prj_id,prj_name, prj_budget) 
(select nd_id, nd_name, nd_budget
 from Newdata)
on duplicate key update
  prj_name   = values(prj_name)
, prj_budget = greatest( coalesce(ac_projects.prj_budget,0), values(prj_budget)
);
