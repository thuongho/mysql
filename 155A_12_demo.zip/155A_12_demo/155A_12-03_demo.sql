use a_testbed;

-- Demo 01	
drop table if exists ddl_alter;
Create table ddl_alter (id integer primary key);
desc ddl_alter;


alter   table  ddl_alter
add     d_office varchar(10);
desc ddl_alter;


alter   table  ddl_alter
add     constraint office_un unique (d_office); 
desc ddl_alter;


-- Demo 02	
alter   table  ddl_alter
add    ( e_ssn char(11)
       , e_namefirst varchar(20) 
       , e_salary numeric(6)  );

desc ddl_alter;


-- Demo 03
alter table ddl_alter 
drop column e_ssn;



-- Demo 04	
alter table ddl_alter 
drop primary key;



-- Demo 05:	
alter   table ddl_alter
modify  e_namefirst varchar(25);


-- Demo 06:	

insert into ddl_alter values (101, 'sales', 'anastasia-marie', 500);

alter   table ddl_alter
modify  e_namefirst varchar(10);


desc ddl_alter;

-- Demo 07
update ddl_alter set e_namefirst = 'sue';


alter   table ddl_alter
modify  e_namefirst varchar(10);

desc ddl_alter;



-- Demo 08
Alter table ddl_alter
Modify e_salary float not null;

desc ddl_alter;

-- Demo 09
Alter table ddl_alter
Modify e_salary real;

desc ddl_alter; 


-- Demo 10
-- invalid
Alter table ddl_alter
change e_namefirst varchar(30) not null;


Alter table ddl_alter
change e_namefirst e_namefirst varchar(30) not null;

