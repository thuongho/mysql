Delimiter #
use a_testbed#
-- demo 01
Show  create function newsalary_6 \G

-- demo 02
delimiter ;
select routine_definition
  from information_schema.routines
  where routine_type = 'function'
  and  routine_name = 'newsalary_6';

  
  -- demo 03
  select parameter_name, ordinal_position, data_type, parameter_mode
from information_schema.parameters
where specific_name = 'newsalary_6';

-- demo 04
select specific_name
, parameter_name
, ordinal_position
, parameter_mode
from information_schema.parameters
where data_type = 'date';


select specific_name
, parameter_name
, ordinal_position
, parameter_mode
from information_schema.parameters
where data_type = 'int';
