Use a_oe;

-- Demo 01	
create or replace view  custReportGoodCredit_01 as 
select 
   cust_id     as CustomerID
,  concat(cust_name_first,  ' ',  cust_name_last) as CustomerName
from  a_oe.customers
where credit_limit > 3000;

-- Demo 02	
Desc custReportGoodCredit_01;

-- Demo 03
Select CustomerName, CustomerID from custReportGoodCredit_01
Order by CustomerID;

-- Demo 04	
create or replace view  ordReport_01 as 
select 
   ord_id      as OrderID 
,  cast(ord_date as date)    as OrderDate
,  cust_id     as CustomerID
,  concat(cust_name_first,  ' ',  cust_name_last) as CustomerName
,  prod_id     as ItemPurchased
,  prod_name   as ItemDescription
,  quoted_price * quantity_ordered as LineTotal
from  a_oe.customers
join  a_oe.order_headers  using (cust_id)
join  a_oe.order_details using(ord_id)
join  a_prd.products using(prod_id)
where quoted_price > 0 and quantity_ordered > 0
;


-- Demo 05:	
Desc a_oe.ordReport_01;


-- Demo 06
select  orderid, orderdate, itempurchased, linetotal
from    ordreport_01
;

-- Demo 07
select  orderid, orderdate, itempurchased 
from    a_oe.ordreport_01
where   orderdate < '2012-01-01'
;

-- Demo 08
select  orderid, orderdate, itempurchased 
from    ordreport_01
where    month(orderdate) in (6,7,8)
and      year(orderdate) in (2011)
limit 8
;


-- Demo 09
select  orderid, orderdate, itempurchased, linetotal
from    ordreport_01
where   linetotal < 100
limit 8
;


-- demo 10
select   orderid
,        itempurchased
,        warehouse_id
,        quantity_on_hand
,        linetotal
from     a_oe.ordreport_01 RPT
join     a_prd.inventory  PRD
      on RPT.itempurchased = PRD.prod_id
where linetotal >500
and  quantity_on_hand < 100
;


-- Demo 11
create or replace view  ordreport_02(orderid, orderdate, customerid, linetotal) as 
select 
   ord_id      
,  ord_date    
,  cust_id     
,  quoted_price * quantity_ordered 
from  a_oe.order_headers  
join  a_oe.order_details using(ord_id)
join  a_prd.products using(prod_id)
where quoted_price > 0 and quantity_ordered > 0
order by ord_id
;



-- Demo 12
show create view a_oe.ordreport_01\G

-- Demo 13
select table_schema, table_name, table_type 
from   information_schema.tables 
where  table_schema = "a_oe";


-- Demo 14

-- Demo 15

			  
-- Demo 16





