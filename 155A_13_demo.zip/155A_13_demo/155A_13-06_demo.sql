use a_testbed;


-- Demo 01	
truncate table ac_emp;
insert into ac_emp values
  (10, 'FREUD',  301, 30000, '2002-06-06', 'PERM')
, (20, 'MATSON', 201, 30000, NULL, 'PERM')
, (30, 'HANSON', 201, 40000, '2003-05-15', 'PERM')
, (40, 'IBSEN',  201, 45000, '2003-05-20', 'PERM')
, (50, 'MILES',  401, 25000, '2003-06-20', 'PERM')
, (60, 'TANG',   401, 25000, '2003-06-20', NULL)
, (70, 'KREMER', 501, 50000, '2003-07-15', NULL)
, (80, 'PAERT',  201, 65000, '2003-07-18', NULL)
, (90, 'JARRET', 301, 60000, '2003-08-08', NULL)
;

-- Demo 02	
REPLACE INTO ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
values ( 101, 'Bensen', 201, 55000, null, null)
;

select * from ac_emp where e_id >= 90;

-- Demo 03
REPLACE INTO ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
values ( 90, 'Williams', 201, 22000, curdate(), null)
;
select * from ac_emp where e_id >= 90;

-- Demo 04	
REPLACE INTO ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
values 
( 101, 'Danson', 201, 55000, null, null)
,
( 103, 'Denver', 301, 35800, '2009-01-25', 'PERM')
;
select * from ac_emp where e_id >= 90;

-- Demo 05:	
REPLACE INTO ac_emp
SET e_id = 104, e_name = 'Paulson', d_id = 401, salary = 45000
;
select * from ac_emp where e_id >= 90;

-- Demo 06
REPLACE INTO ac_emp
SET e_id = 104, e_name = 'Peterson', d_id = 401, hiredate=curdate()
;
select * from ac_emp where e_id >= 90;

-- Demo 07
create table ac_emp_changes like ac_emp;

insert into ac_emp_changes values 
   ( 105, 'Adams',   401, 45900, '2010-04-15', 'PERM')
,  ( 106, 'Baker',   401, 35800, '2010-04-15', 'PERM')
,  (  90, 'Carlson', 401, 25700, '2010-04-15', 'PERM')
,  ( 101, 'Dobson',  401, 30300, '2010-04-15', 'PERM')
;

select * from ac_emp_changes;

-- Demo 08
replace into ac_emp
select * from ac_emp_changes;

select * from ac_emp where e_id >= 90;

-- Demo 09
create table ac_proj1 ( e_id decimal(3,0), pr_id int
, constraint ac_proj1_pk primary key(e_id, pr_id)
, constraint ac_proj1_pk foreign key(e_id) references ac_emp(e_id)
);
truncate table ac_proj1;

insert into ac_proj1  values ( 60, 101), (60, 102), (60, 103), (70,101);


create table ac_emp_changes2 like ac_emp;

truncate table ac_emp_changes2 ;
insert into ac_emp_changes2 values 
   ( 60, 'Adams',   401, 25000, '2003-06-20', null)
,  ( 70, 'Baker',   501, 50000, '2003-07-15', null)
,  ( 80, 'Charlie', 201, 65000, '2003-07-15', null)
;

-- Demo 10
replace into ac_emp
select * from ac_emp_changes2;

-- Demo 11
drop table ac_proj1;

create table ac_proj2 ( e_id decimal(3,0), pr_id int
, constraint ac_proj2_pk primary key(e_id, pr_id)
, constraint ac_proj2_pk foreign key(e_id) references ac_emp(e_id) on delete cascade
);
delete from ac_proj2;

insert into ac_proj2  values ( 60, 101), (60, 102), (60, 103), (70,101), (80, 101), (90,101);
select * from ac_proj2;



-- Demo 12
replace into ac_emp
select * from ac_emp_changes2;

select * from ac_proj2;

select * from ac_emp where e_id in (60,70,80);

-- Demo 13
Create table z_repl_test  (
   id     int primary key, 
   cl_id  int unique, 
   name   varchar(15));
Insert into z_repl_test   values (1, 10, 'cat');
Insert into z_repl_test   values (2, 20, 'dog');

select * from z_repl_test;

-- demo 14
replace into z_repl_test values ( 3, 20, 'elephant');
select * from z_repl_test;
-- Demo 15
replace into z_repl_test values ( 1, 20, 'fox');


-- Demo 16
truncate table ac_emp_changes2;
insert into ac_emp_changes2 (e_id, e_name, d_id, salary) values
   (  60, 'Bobby',   401, 20900)
,  (  70, 'Billy',   501, 25000)
,  (  80, 'Bret',    201, 75000)
;

-- Demo 17
replace into ac_emp
select E.e_id, C.e_name, C.d_id
, greatest(coalesce(E.salary,0), coalesce(C.salary,0), 35000) salary
, date_add(E.hiredate, interval -6 month)   hiredate
, E.e_status
from ac_emp  E
join ac_emp_changes2  C  on E.e_id = C.e_id;

