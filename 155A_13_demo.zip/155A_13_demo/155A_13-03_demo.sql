use a_prd;


-- Demo 01	
Create table z_autoIncr_1 (
   col_1 integer unsigned auto_increment primary key 
,  col_2 varchar(15)) engine= innodb;

insert into z_autoIncr_1 (col_2 ) values ('Ann');
insert into z_autoIncr_1 (col_2 ) values ('Betsy');
insert into z_autoIncr_1 (col_2 ) values ('Carla');
insert into z_autoIncr_1 (col_2 ) values ('Darlene');

select * from z_autoIncr_1;


-- Demo 02	
insert into z_autoIncr_1 values ( null, 'Eartha');
insert into z_autoIncr_1 values (null, 'Fanny');
select * from z_autoIncr_1;

-- Demo 03
delete from z_autoIncr_1 where col_1 = 4;
select * from z_autoIncr_1;

-- Demo 04	
insert into z_autoIncr_1 (col_2 ) values ('Darlene');
select * from z_autoIncr_1;

-- Demo 05:	
insert into z_autoIncr_1 values (66, 'Annabelle');
insert into z_autoIncr_1 values (null, 'Barbar');
insert into z_autoIncr_1 values (null, 'Curtis');

select * from z_autoIncr_1;

-- Demo 06
Set @@auto_increment_increment = 5;

Create table z_autoIncr_2 (
   col_1 integer unsigned auto_increment primary key 
,  col_2 varchar(15)) engine= innodb;


insert into z_autoIncr_2 (col_2 ) values ('ant');
insert into z_autoIncr_2 (col_2 ) values ('beetle');
insert into z_autoIncr_2 (col_2 ) values ('cricket');
insert into z_autoIncr_2 (col_2 ) values ('dragonfly');
select * from z_autoIncr_2;


-- Demo 07
insert into z_autoIncr_1 values (null, 'Douglas');  -- this gets +3
insert into z_autoIncr_1 values (null, 'Evens');    -- this gets +5
insert into z_autoIncr_1 values (null, 'Frank');    -- this gets +5
insert into z_autoIncr_1 values (null, 'George');   -- this gets +5

select * from z_autoIncr_1;


-- Demo 08
Set @@auto_increment_offset =25, @@auto_increment_increment = 25;

Create table z_autoIncr_3 (
   col_1 integer unsigned auto_increment primary key 
,  col_2 varchar(15)) engine= innodb;

insert into z_autoIncr_3 (col_2 ) values ('Ann');
insert into z_autoIncr_3 (col_2 ) values ('Betsy');
insert into z_autoIncr_3 (col_2 ) values ('Carla');
insert into z_autoIncr_3 (col_2 ) values ('Darlene');

select * from z_autoIncr_3;


-- Demo 09
set @@auto_increment_offset = 1, @@auto_increment_increment = 1;

create table z_autoincr_4 (
 col_1 int not null auto_increment primary key,
 col_2 int not null
) engine= innodb;


insert into z_autoincr_4 (col_1, col_2) values (0, 101);
insert into z_autoincr_4 (col_1, col_2) values (-1, 102);
insert into z_autoincr_4 (col_1, col_2) values (9999999999, 103);

insert into z_autoincr_4  col_1, col_2) values (1, 104);


insert into z_autoincr_4 (col_1, col_2) values (0, 105);
insert into z_autoincr_4 (col_1, col_2) values (2147483647, 106);

select * from z_autoincr_4;


-- demo 10
create table z_autoincr_5 (
 col_1 int not null auto_increment primary key,
 col_2 int not null
) engine= innodb;


insert into z_autoincr_5  (col_1, col_2) values (0, 101);
insert into z_autoincr_5   (col_1, col_2) values (null, 102);
insert into z_autoincr_5   (col_1, col_2) values (0, 103);
insert into z_autoincr_5   (col_1, col_2) values (0, 104);


alter table z_autoincr_5 auto_increment = 500;
insert into z_autoincr_5   (col_1, col_2) values (0, 105);
insert into z_autoincr_5   (col_1, col_2) values (0, 106); 

select * from z_autoincr_5;


-- Demo 11



-- Demo 12


-- Demo 13


-- Demo 14

-- Demo 15

			  
-- Demo 16





