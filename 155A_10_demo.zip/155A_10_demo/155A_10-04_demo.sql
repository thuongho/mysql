use a_prd;

/*  Demo 01  */	
drop view if exists a_prd.Prod_HW_APL;

Create view  a_prd.Prod_HW_APL as (
select 
prod_id , prod_name, prod_list_price
from a_prd.products  
where catg_id in ('APL', 'HW')
);


/*  Demo 02  */	
Select * 
from a_prd.Prod_HW_APL
;

/*  Demo 03  */	
Select * 
from a_prd.Prod_HW_APL
where prod_list_price > 100;



/*  Demo 04  */	
Select PR.prod_id, quantity_ordered * quoted_price as ExtPrice , ord_id
from a_prd.Prod_HW_APL PR
join a_oe.order_details OD on PR.prod_id = OD.prod_id
where ord_id  between 110 and 115;


/*  Demo 05  */	
drop view if exists a_oe.cust_orders;

Create view  a_oe.cust_orders as (
select 
   OH.ord_id  as Invoice  
,  OH.ord_date as OrderDate
,  OH.cust_id  as CustID
,  PR.catg_id  as Category
,  OD.prod_id  as ItemPurchased
from a_oe.order_headers  OH 
join a_oe.order_details  OD on OH.ord_id= OD.ord_id
join a_prd.products      PR on OD.prod_id = PR.prod_id
where OD.quoted_price > 0 
and OD.quantity_ordered > 0
);



/*  Demo 06  */	
Select Invoice, ItemPurchased
from a_oe.cust_orders
Where month(OrderDate) = 6;



