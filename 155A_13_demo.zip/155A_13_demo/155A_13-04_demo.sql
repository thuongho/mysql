Use a_testbed;

-- Demo 01	
delete from a_emp.employees where  emp_id = 1995;
insert into a_emp.employees values 
   (1995,'Zahn', 'Joe', '111111111', 100, 10, '2009-09-09', 500, 2);

delete from  a_prd.products  where  prod_id = 1995;
insert into a_prd.products values
(1995, 'book','Train your cat book',29.95, 'PET', null);


-- Demo 02	
CREATE or replace VIEW vw_emp AS 
    select   emp_id, name_last, name_first 
    from     a_emp.employees; 

	
select * from vw_emp;


select name_first, name_last 
from   a_emp.employees 
where emp_id = 1995;


-- Demo 03
Update vw_emp 
set name_first = 'Susan' 
where emp_id = 1995;

select name_first, name_last 
from   a_emp.employees 
where emp_id = 1995;

-- Demo 04	 fails
Update vw_emp 
set salary = 12500 
where emp_id = 1995;



-- Demo 05:	
Update vw_emp 
set name_last = null
 where emp_id = 1995;


Delete from vw_emp 
where emp_id = 5;


-- Demo 06
CREATE VIEW vw_high_price_by_category AS
    select   Catg_id, MAX(prod_list_price) As HighPrice
    from     a_prd.products
    group by Catg_id;


-- Demo 07
update  vw_high_price_by_category
set     HighPrice = 250
where   catg_id = 'PET'
;


-- Demo 08
CREATE  VIEW vw_new_price AS
    select   catg_id, prod_name, Round(prod_list_price * 1.05,2) As NewPrice
    from     a_prd.products;


-- Demo 09
Update vw_new_price 
set NewPrice = 45 
where prod_name like '%Cat%';


-- demo 10
CREATE  VIEW vw_new_price_2 AS
    select   catg_id, prod_name, prod_list_price * 1 As NewPrice
    from     a_prd.products;

Update vw_new_price_2 
set NewPrice = 45 
where prod_name like '%Cat%';

-- Demo 11
CREATE  VIEW vw_em_dept_1 AS
    select  E.emp_id, E.name_last
    ,       E.dept_id
    ,       D.dept_name
    from    a_emp.employees   E
    join    a_emp.departments D on  E.dept_id = D.dept_id;



-- Demo 12
CREATE  VIEW vw_em_dept_2 AS
    select  E.emp_id, E.name_last
    ,       D.dept_id
    ,       D.dept_name
    from    a_emp.employees   E
    join    a_emp.departments D on  E.dept_id = D.dept_id;


	
	Select * from  vw_em_dept_1;
	Select * from  vw_em_dept_2;
	
-- Demo 13
update   vw_em_dept_2
set     dept_id = 80
where   emp_id = 1995
;

update   vw_em_dept_1
set     dept_id = 80
where   emp_id = 1995
;

-- Demo 14
CREATE  VIEW product_list AS
    select   prod_id + 0 as prod_id
           , prod_list_price as prod_list_price
           , prod_name + '' as prod_name
           , prod_desc 
    from     a_prd.products
;


-- Demo 15
Update product_list 
set prod_list_price = 15 
where prod_id = 1995;

			  
-- Demo 16
Update product_list  
set prod_name = 'Cats and me' 
where prod_id = 1995;


-- demo 17
CREATE  VIEW emp_dept_80 AS
    select   emp_id, name_last
    ,        dept_id
    from     a_emp.employees 
    where    dept_id = 80
WITH CHECK OPTION;


-- demo 18
update   emp_dept_80
set      name_last = 'Hoyer'
where   emp_id = 1995

-- demo 19
update   emp_dept_80
set      dept_id = 20
where   emp_id = 1995
;


-- demo 20
CREATE OR REPLACE VIEW EmpHighSalary AS
    select   emp_id, name_last, salary
    ,        dept_id
    from     a_emp.employees 
    where    salary > 70000
WITH CHECK OPTION;

-- the record set 
select * 
from EmpHighSalary;

-- demo 21
update  a_emp.employees   
set     name_last = 'Prince',
        salary = 75000
where   emp_id = 1995;

-- Demo 25:	
update  EmpHighSalary 
set     name_last = 'Prince',
        salary = 85000
where   emp_id = 1995;

-- Demo 26:	
update   EmpHighSalary 
set      name_last = 'Koch',
         salary = 10000
where    emp_id = 1995
;

