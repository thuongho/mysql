Use a_emp;

/*  Demo 01 */	
select    AVG(prod_list_price) as "AvgPrice"
from      a_prd.products
;

/*  Demo 02 */	
select    Avg(prod_list_price) as "AvgPrice"
from      a_prd.products
where     catg_id = 'HW';

/*  Demo 03 */	
select    Avg(prod_list_price) as "Avg Price"
,         Min(prod_list_price) as "Min Price"
,         Max(prod_list_price) as "Max Price"
from      a_prd.products
where     catg_id = 'HW'
;

/*  Demo 04 */	
select    Avg(prod_list_price) as "AvgListPrice"
,         Avg(quoted_price) as "AvgQuotedPrice"
,         Avg(quoted_price* quantity_ordered) as "AvgExtendedCost"
,         SUM(quoted_price* quantity_ordered) as "TotalExtendedCost"
from      a_prd.products 
join      a_oe.order_details using (prod_id)
where     catg_id = 'HW';

/*  Demo 05 */	
select    round(Avg(prod_list_price),0) as "Avg Price"
,         Max(prod_list_price) - Min(prod_list_price) as "Price Range"
from      a_prd.products
;

/*  Demo 06 */	
select    Max(prod_list_price) as "Max Price"
from      a_prd.products
;

/*  Demo 07 */	
select    Max(prod_list_price) as "Max Price"
,         prod_id
from      a_prd.products
;

/*  Demo 08 */	
select    prod_id
,         prod_name
,         prod_list_price
from      a_prd.products
where     prod_list_price = MAX(prod_list_price) ;

/*  Demo 09 */	
select     prod_id
,          prod_name
,          prod_list_price
from       a_prd.products
where      prod_list_price = (
             select MAX(prod_list_price) as "Largest Price"
             from   a_prd.products)
;


/*  Demo 10 */	
select     prod_id
,          prod_name
from       a_prd.products
where      prod_list_price = (
             select MAX(prod_list_price) as "Largest Price"
             from   a_prd.products
             where  catg_id = 'SPG')
;


/*  Demo 11 */	
set @catg_id = 'SPG';
select     prod_id
,          prod_name
from       a_prd.products
where      catg_id = @catg_id 
and        prod_list_price = (
             select    MAX(prod_list_price) as "Largest Price"
             from      a_prd.products
             where catg_id = @catg_id )
;

/*  Demo 12 */	
set @catg_id = 'PET';

select     prod_id
,          prod_name
from       a_prd.products
where      catg_id = @catg_id 
and        prod_list_price = (
             select    MAX(prod_list_price) as "Largest Price"
             from      a_prd.products
             where catg_id = @catg_id )
;


/*  Demo 13 */	
Select min(ord_date) as "Earliest"
From a_oe.order_headers;

/*  Demo 14 */	
Select min(hire_date) as "Earliest"
, max(hire_date)      as "Recent"
From a_emp.employees;

/*  Demo 15 */	
Select min(name_last), max(name_last)  
From a_emp.employees;




/*  Demo 16 */	
select    COUNT(prod_id) as "Number of Products"
,         COUNT(prod_warranty_period)  as "Number with warranty"
from      a_prd.products
;

/*  Demo 17 */	
select    COUNT(prod_id) as "Number of Products"
,         COUNT(*)  as         "Number of rows *"
,         COUNT(1)  as         "Number of rows 1"
from      a_prd.products
;

/*  Demo 18 */	
select    Count(Distinct prod_id)
from      a_oe.order_details 
;

/*  Demo 19 */	
select    Count( ord_id)
from      a_oe.order_headers 
;

/*  Demo 20 */	
select count( ord_id), count(distinct ord_id)
from a_oe.order_details;


/*  Demo 21 */	
select count( distinct cust_id), count(cust_id)
from a_oe.order_headers;



/*  Demo 22 */	
select count( distinct cust_id, shipping_mode)
from a_oe.order_headers
where shipping_mode is not null;

/*  Demo 23  */

Select count(cust_id) as Count
, count(distinct cust_id) as CountDistinct
From a_oe.customers ;