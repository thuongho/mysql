use a_testbed;

-- Demo 01	
show create table a_testbed.zoo_animals\G

-- Demo 02	
show databases;   
show tables from information_schema;

-- Demo 03
desc information_schema.tables;

select table_name, create_time
from information_schema.tables
where table_schema= 'a_emp';

-- Demo 04	
desc information_schema.table_constraints;


Select  TC.table_name , count(*)
from    information_schema.table_constraints TC
where   TC.table_schema= 'a_emp'
and     TC.constraint_type = 'FOREIGN KEY'
group by TC.table_name

-- Demo 05:	
desc information_schema.columns;

select table_name, column_name, data_type
from information_schema.columns
where table_schema= 'a_emp'
and data_type not in ('CHAR', 'VARCHAR');

-- Demo 06
select table_schema, table_name, table_type, table_rows
from information_schema.tables
where table_schema= 'a_emp';


-- Demo 07
use a_emp;

Show tables;

-- Demo 08
select  TC.table_name, TC.constraint_name, TC.constraint_type
from    information_schema.table_constraints TC
where   TC.table_schema= 'a_emp';


-- Demo 09
Select  TC.table_name, TC.constraint_name, TC.constraint_type
from    information_schema.table_constraints TC
where   TC.table_schema= 'a_emp'
and     constraint_type <> 'PRIMARY KEY';



-- Demo 10
Create table a_emp.vt_temp (col_id int);

Select  TC.table_name, TC.constraint_name, TC.constraint_type
from    information_schema.table_constraints TC
where   TC.table_schema= 'a_emp';


-- Demo 11
select  Concat(T.table_schema,'- - - ', T.table_name)
from    information_schema.tables T
where    T.table_schema= 'a_emp'
and
  Concat(T.table_schema,'- - - ', T.table_name) NOT IN
 (  select Concat(TC.table_schema,'- - - ', TC.table_name)
from   information_schema.table_constraints TC
where  TC.table_schema= 'a_emp'
and    TC.constraint_type = 'PRIMARY KEY');


-- Demo 12
Select  Concat(T.table_schema,'- - - ', T.table_name)
from    information_schema.tables T
where 
   T.table_schema= 'a_emp'
and
   T.TABLE_TYPE = 'BASE TABLE'     
and
  Concat(T.table_schema,'- - - ', T.table_name) NOT IN
 (  select Concat(TC.table_schema,'- - - ', TC.table_name)
from   information_schema.table_constraints TC
where  TC.table_schema= 'a_emp'
and    TC.constraint_type = 'PRIMARY KEY');


-- Demo 13
drop table a_emp.vt_temp;

-- Demo 14
show tables;

show full tables from a_testbed Like 'ddl%' ;

show full tables from a_oe;




