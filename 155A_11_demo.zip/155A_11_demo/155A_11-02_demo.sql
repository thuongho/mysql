
-- Demo 01:	
select *
from  ( select * 
        from a_emp.jobs) tbl
;


select job_Id,  job_title, max_salary
from  ( select job_Id, job_title , max_salary  
        from a_emp.jobs
        where max_salary is not null) tbl
;

-- Demo 02:	
select   COUNT(DISTINCT shipping_mode) as num_diff_ship_modes
from     a_oe.order_headers
;

-- Demo 03:	
select   count(distinct coalesce(shipping_mode, 'none')) 
         as num_diff_ship_modes
from     a_oe.order_headers
;

-- Demo 04:	
select   count(*) as num_diff_ship_modes
from    (select  distinct shipping_mode
         from    a_oe.order_headers) tbl
;

-- Demo 05:	
select  distinct shipping_mode, ord_mode
from    a_oe.order_headers
order by shipping_mode, ord_mode
;

-- Demo 06:	
select   count(*) as num_diff_modes
from     (select  distinct shipping_mode, ord_mode
          from    a_oe.order_headers) tbl
;

-- Demo 07:	
select   count(distinct shipping_mode, ord_mode) as  num_diff_modes
from     a_oe.order_headers
;

-- Demo 08:	
 
select d.dept_id, count(*)
from   a_emp.departments d
left join a_emp.employees e on d.dept_id = e.dept_id
group by d.dept_id
;

-- Demo 09:	
select d.dept_id, count(e.emp_id)
from   a_emp.departments d
left join a_emp.employees e on d.dept_id = e.dept_id
group by d.dept_id
;

-- Demo 10:	
select d.dept_id, d.dept_name, count(e.emp_id)
from   a_emp.departments d
left join a_emp.employees e on d.dept_id = e.dept_id
group by d.dept_id
;

-- Demo 11:	
select dept_id, count(*) as EmpCount
from   a_emp.employees e
group by dept_id
;

-- Demo 12:	
select D.dept_id, D.dept_name, EC.EmpCount
from a_emp.departments d
left join (
   Select dept_id, count(*) as EmpCount
   From a_emp.employees
   group by dept_id) ec  on d.dept_id = ec.dept_id
;

-- demo 13
select D.dept_id, D.dept_name
,  concat(l.loc_city, ' ',  l.loc_state_province)  as Location
,  coalesce(EmpCount,0) as EmpCount
from a_emp.departments D
join a_emp.locations L on D.loc_id = l.loc_id
left join ( 
   select dept_id, count(emp_id) as EmpCount 
   from   a_emp.employees E
   group by dept_id) EC on D.dept_id = EC.dept_id
;

-- Demo 14	
select 
  dept_id
, dept_count
, Round((dept_count / Count_All),2) AS Percnt
from 
   (select dept_id, count(1) AS dept_count  /* get count by department */
    from   a_emp.employees
    group  by dept_id)  vt1,   /* get total count for all employees */ 
   (select  count(*) AS Count_All
    from    a_emp.employees)   vt2
order by Dept_id
;

-- Demo 15	
select 
  dept_id
, dept_count
, concat(Round((100. * dept_count / Count_All),0), '%') AS Percnt
from 
   (select dept_id, count(1) AS dept_count  
    from   a_emp.employees
    group  by dept_id)  vt1, 
   (select  count(*) AS Count_All
    from    a_emp.employees)   vt2
order by Dept_id
;

-- Demo 15:	
select CS.cust_id, CS.credit_limit, CR.rating
from   a_oe.customers  CS
join   a_oe.credit_ratings CR on  
         CS.credit_limit between CR.low_limit and CR.high_limit
;

-- demo 16
select distinct tblapl.custid
from    
    (select   CustID
     from     a_oe.cust_orders
     where    category ='APL' )  tblapl 
 join
    (select     CustID
     from    a_oe.cust_orders
     where    Category ='HW' )  tblhw  
   On tblapl.custid = tblhw.custid     
;

-- demo 17
select CS.cust_id, CS.credit_limit, CR.rating
from   a_oe.customers  CS
join   a_oe.credit_ratings CR on  
         CS.credit_limit between CR.low_limit and CR.high_limit;

-- Demo 18:	
  select 'under paid' as catg, 0 as low, 19999.99 as high 
  union all
  select 'medium paid' as catg, 20000.00 as low, 79999.99 as high 
  union all
  select 'over paid' as catg, 80000.00 as low, 9999999.99 as high ;

-- Demo 19:	
select emp_id, name_last,salary, catg
from a_emp.employees E
join (
     select 'under paid' as catg, 0 as low, 19999.99 as high   union all
     select 'medium paid' as catg, 20000.00 as low, 79999.99 as high 
   union all
     select 'over paid' as catg, 80000.00 as low, 9999999.99 as high 
  ) Ratings on E.salary between Ratings.low and Ratings.high
order by salary
;

-- Demo 20:	
select emp_id, name_last,salary 
,  case 
     when salary between 0 and 19999.99 then 'under paid'
     when salary between 20000.00 and 79999.99 then 'medium paid'
     when salary between 80000.00 and 9999999.99 then 'over paid'
   end as catg
from a_emp.employees E
order by salary;

-- Demo 21:	
select catg, count(*)as NumEmployees
from   a_emp.employees E
join (
  select 'under paid' as catg, 0 as low, 19999.99 as high 
  union all
  select 'medium paid' as catg, 20000.00 as low, 79999.99 as high 
  union all
  select 'over paid' as catg, 80000.00 as low, 9999999.99 as high 
  ) Ratings on E.salary between Ratings.low and Ratings.high
GROUP by catg
;




