use a_prd;

/*  Demo 01  */	
 select   prod_id, catg_id, prod_name
   from     a_prd.products 
   where    prod_id in (
            select prod_id 
            from  a_oe.order_details  
            join  a_oe.order_headers  using (ord_id)
            where    catg_id = 'HW' 
            and      extract(month from ord_date) = 11 )
   and       prod_id in (
            select prod_id 
            from  a_oe.order_details  
            join  a_oe.order_headers  using (ord_id)
            where    catg_id = 'HW' 
            and      extract(month from ord_date) = 12 )
;

/*  Demo 02  */	
 select   prod_id, catg_id, prod_name
   from     a_prd.products 
   where    prod_id in (
            select prod_id 
            from  a_oe.order_details  
            join  a_oe.order_headers  using (ord_id)
            where    catg_id = 'HW' 
            and      extract(month from ord_date) = 11 )
   and       prod_id NOT in (
            select prod_id 
            from  a_oe.order_details  
            join  a_oe.order_headers  using (ord_id)
            where    catg_id = 'HW' 
            and      extract(month from ord_date) = 12 )
; 

/*  Demo 03  */	
  select   prod_id, catg_id, prod_name
   from     a_prd.products 
   where    prod_id NOT in (
            select prod_id 
            from  a_oe.order_details  
            join  a_oe.order_headers  using (ord_id)
            where    catg_id = 'HW' 
            and      extract(month from ord_date) = 11 )
   and       prod_id in (
            select prod_id 
            from  a_oe.order_details  
            join  a_oe.order_headers  using (ord_id)
            where    catg_id = 'HW' 
            and      extract(month from ord_date) = 12 )
; 
