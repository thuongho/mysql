
create table TodaysSpecials (an_type varchar(15));
insert into TodaysSpecials values ('fish');
insert into TodaysSpecials values ('cat');

-- Demo 01:	
select *
from   zoo_ex
where an_type = ANY  (
    select an_type 
    from   todaysSpecials )  
;

-- Demo 02:	
select *
from   zoo_ex
where an_type = ALL  (
    select an_type 
    from   todaysSpecials ) ;

-- Demo 03:	
select * from zoo_ex 
where  an_price > ANY (select an_price from zoo_ex)
order by an_price;

-- Demo 04:	
select * from zoo_ex 
where  an_price >= ANY (select an_price from zoo_ex)
order by an_price;

-- Demo 05:	
select * 
from zoo_ex
where  an_price > All (select an_price from zoo_ex)
order by an_price;

-- Demo 06:	
select * 
from zoo_ex
where  an_price >= All (select an_price from zoo_ex)
order by an_price;

-- Demo 07:	
select * 
from zoo_ex
where  an_price >= All (
    select an_price 
    from   zoo_ex
    where an_price is not null)
order by an_price;

-- Demo 08:		
select * 
from zoo_ex
where  an_price = ANY (
    select an_price 
    from   zoo_ex 
    where  an_price is not null
    and    an_type ='bird')
;

-- Demo 09:	
select * 
from zoo_ex
where an_price = ANY (
    select an_price 
    from   zoo_ex 
    where  an_type ='lizard'
    and    an_price is not null)

-- Demo 10:	
select * 
from zoo_ex
where  an_price = All (
    select an_price 
    from   zoo_ex 
    where  an_price is not null
    and    an_type ='bird')
; 

-- Demo 11:	
select * from zoo_ex
where  an_price = All (
    select an_price 
    from   zoo_ex 
    where an_price is not null
    and   an_type ='lizard')
;

-- Demo 12:	
select distinct an_type 
from   zoo_ex p1
where  an_price = All (
    select an_price 
    from   zoo_ex  p2
    where  an_price is not null
    and    p1.an_type = p2.an_type ) 
;

-- Demo 13:	
select distinct an_type 
from   zoo_ex p1
where  an_price = All (
    select an_price 
    from   zoo_ex  p2
    where  p1.an_type = p2.an_type ) 
;

-- Demo 14:	
select an_type 
from   zoo_ex p1
where  an_price = All (
    select an_price 
    from   zoo_ex  p2
    where  an_price is not null
    and    p1.an_type = p2.an_type ) 
group by an_type
having count(*) > 1
;

-- Demo 15:	
select distinct an_type 
from   zoo_ex p1
where  an_price = All (
    select an_price 
    from   zoo_ex  p2
    where  p1.an_type = p2.an_type ) 
group by an_type
having count(*) > 1  
;

-- Demo 16:	
select PR.prod_id, PR.prod_name 
from   a_prd.products  PR
where  catg_id = 'HD'
order by prod_id
;

select   PR.prod_id
,        PR.prod_name
,        PR.prod_list_price
,        OD.quoted_price
,        PR.prod_list_price - OD.quoted_price as price_diff
from     a_prd.products  PR
join     a_oe.order_details  OD on PR.prod_id = OD.prod_id
where    PR.catg_id = 'HD'
order by PR.prod_id
;

-- Demo 17:	
select distinct PR.prod_id, pr.prod_name
from   a_prd.products  PR
join   a_oe.order_details  OD on PR.prod_id = OD.prod_id
where  catg_id = 'HD'
and    prod_list_price > ALL (
        select quoted_price
        from   a_oe.order_details  OD2
        where  OD2.prod_id =PR.prod_id )
;


-- Demo 18:	
select distinct PR.prod_id, pr.prod_name
from   a_prd.products  PR
join   a_oe.order_details  OD on PR.prod_id = OD.prod_id
where  catg_id = 'HD'
and    prod_list_price > ANY (
        select quoted_price
        from   a_oe.order_details  OD2
        where  OD2.prod_id =PR.prod_id)
;

-- Demo 19:	
select distinct PR.prod_id, pr.prod_name
from   a_prd.products  PR
join   a_oe.order_details  OD on PR.prod_id = OD.prod_id
where  catg_id = 'HD'
and    prod_list_price = ALL (
        select quoted_price
        from   a_oe.order_details  OD2
        where  OD2.prod_id =PR.prod_id )
;

-- Demo 20:	
select distinct PR.prod_id, pr.prod_name
from   a_prd.products  PR
join   a_oe.order_details  OD on PR.prod_id = OD.prod_id
where  catg_id = 'HD'
and    prod_list_price = ANY (
        select quoted_price
        from   a_oe.order_details  OD2
        where  OD2.prod_id =PR.prod_id) 
;
