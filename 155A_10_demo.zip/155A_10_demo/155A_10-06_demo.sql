use a_oe;

/*  Demo 01  */   
select   credit_limit
from     a_oe.customers
where    cust_id in (  
           select   cust_id 
           from     a_oe.order_headers   )
 order by credit_limit desc;

/*  Demo 02  */   
select cust_name_last
,      cust_name_first
,      cust_id
from   a_oe.customers
where  cust_id IN ( 
     select  cust_id     
     from    a_oe.order_headers
     where   ord_id  IN ( 
          select ord_id  
          from   a_oe.order_details
          where  prod_id = 1020)  )
order by cust_id
;

/*  Demo 03  */   
select Distinct
   CS.cust_name_last
,  CS.cust_name_first
,  CS.cust_id
from   a_oe.customers CS
join   a_oe.order_headers  OH on CS.cust_id = OH.cust_id
join   a_oe.order_details  OD on OH.ord_id = OD.ord_id
where  OD.prod_id = 1020
order by cust_id
;

/*  Demo 04  */   
select cust_name_last
,      cust_name_first
,      cust_id
from   a_oe.customers
where  cust_id IN ( 
     select  cust_id     
     from    a_oe.order_headers
     where   ord_id  IN ( 
          select ord_id  
          from   a_oe.order_details
          where  prod_id  in ( 
             select prod_id
             from a_prd.products
             where catg_id = 'APL') )  )
order by cust_id
;

/*  Demo 05  */   
select   cust_id, cust_name_last, cust_name_first
from     a_oe.customers
where    cust_id = (  
           select   cust_id 
           from     a_oe.order_headers 
           where    Ord_id  = 115)
; 

/*  Demo 06  */   
set @prod_id  := 5004;

select   cust_id, cust_name_last, cust_name_first
from     a_oe.customers
where    cust_id = (  
           select   cust_id 
           from     a_oe.order_headers  OH 
           join     a_oe.order_details  OD on OH.ord_id = OD.ord_id         
           where    prod_id  =@prod_id);



/*  Demo 07  */   
set @empId  := 145;

select emp_id
from   a_emp.employees
where  emp_id  <> @empId  
and    emp_mng  =
     ( select emp_mng  
       from   a_emp.employees
       where  emp_id  = @empId  );


/*  Demo 08  */   
set @empId  = 100;

select emp_id
from   a_emp.employees
where  emp_id  <> @empId  
and    emp_mng  =
     ( select emp_mng  
       from   a_emp.employees
       where  emp_id  = @empId  );


/*  Demo 09  */   
set @empId   := 408;
select emp_id
from   a_emp.employees
where  emp_id  <> @empId  
and    emp_mng  =
     ( select emp_mng  
       from   a_emp.employees
       where  emp_id  = @empId  );



/*  Demo 10  */   
select prod_id
,      prod_name
,      catg_id
,      prod_list_price
from   a_prd.products
where  prod_list_price >  (
     select avg(prod_list_price) 
     from   a_prd.products    );


/*  Demo 11  */   
select prod_id
,      prod_name
,      catg_id
,      prod_list_price
from   a_prd.products
where  prod_list_price between  
         (select avg(prod_list_price) 
          from   a_prd.products  ) - 100
     and 
         (select avg(prod_list_price) 
         from   a_prd.products  ) + 100
;



/*  Demo 12  */   
/*
select cust_id, ord_date 
from a_oe.order_headers 
order by ord_date;

*/
select   cust_id, cust_name_last, cust_name_first
from     a_oe.customers
where    cust_id  = (  
           select   cust_id 
           from     a_oe.order_headers 
           where  ord_date  = '2013-05-12')
; 

/*  Demo 13  */   
select   cust_id, cust_name_last, cust_name_first
from     a_oe.customers
where    cust_id IN (  
           select   cust_id 
           from     a_oe.order_headers 
           where  ord_date  = '2013-05-12')
; 

/*  Demo 14  */   
select   cust_id, cust_name_last, cust_name_first
from     a_oe.customers
where    cust_id IN (  
           select   cust_id 
           from     a_oe.order_headers 
           where  ord_date  = '1888-08-08')
; 

/*  Demo 15  */   
select   cust_id, cust_name_last, cust_name_first
from     a_oe.customers
where    cust_id  NOT IN (  
           select   cust_id 
           from     a_oe.order_headers 
           where  ord_date  = '1888-08-08');

/*  Demo 16  */   
select a_oe.customers.cust_id
,      cust_name_last, cust_name_first 
from   a_oe.customers 
join   a_oe.order_headers on a_oe.customers.cust_id= a_oe.order_headers.cust_id
where  month (ord_date) = 12 and year(ord_date) = 2012
;

/*  Demo 17  */   
select cust_id, cust_name_last, cust_name_first  
from   a_oe.customers
where  cust_id IN ( 
     select cust_id  
     from   a_oe.order_headers
     where  month (ord_date) = 12 and year(ord_date) = 2012)
;

/*  Demo 18  */   
select CS.cust_id, CS.cust_name_last
from   a_oe.customers  CS
left join  a_oe.order_headers OH on CS.cust_id = OH.cust_id
where  OH.ord_id is null
;


/*  Demo 19  */   
select a_oe.customers.cust_id, cust_name_last
from   a_oe.customers 
where  cust_id not in (
           select cust_id 
           from   a_oe.order_headers );

/*  Demo 20  */   
select Ord_id, ord_date
from   a_oe.order_headers
where  ord_id not in ( 
           select ord_id
           from   a_oe.order_details )
;

/*  Demo 21  */   
set @catg = 'PET' ;

select prod_id
,      prod_name
,      catg_id
,      prod_list_price
from   a_prd.products
where  prod_list_price =  (
     select max(prod_list_price) 
     from   a_prd.products 
     where  catg_id = @catg)
;

/*  Demo 22  */   
select prod_id
,      prod_name
,      catg_id
,      prod_list_price
from   a_prd.products
where  catg_id = @catg
and    prod_list_price =  (
     select max(prod_list_price) 
     from   a_prd.products 
     where  catg_id = @catg)
;

/*  Demo 23  */   
select distinct cust_id, prod_id
from   a_oe.order_headers OH
join   a_oe.order_details OD on OH.ord_id = OD.ord_id
where  prod_id in (
   select   prod_id
   from     a_prd.products
   where    catg_id = @catg
   and      prod_list_price =  (
     select  max(prod_list_price) 
     from    a_prd.products 
     where   catg_id = @catg)
     );

set @catg = 'SPG' ;

/*  Demo 24  */   
Create or replace view  a_oe.oe_cust_orders as (
select 
   OH.ord_id  as Invoice  
,  OH.ord_date as OrderDate
,  OH.cust_id  as CustID
,  PR.catg_id  as Category
,  OD.prod_id  as ItemPurchased
from a_oe.order_headers  OH 
join a_oe.order_details  OD on OH.ord_id= OD.ord_id
join a_prd.products      PR on OD.prod_id = PR.prod_id
where OD.quoted_price > 0 
and OD.quantity_ordered > 0
);

/*  Demo 25  */   
Select * 
from a_oe.oe_cust_orders 
order by invoice, category;


/*  Demo 26  */   
select   distinct 
         custid
,        invoice
,        category
from     a_oe.oe_cust_orders
where    category <> 'APL' 
and      oe_cust_orders.invoice in ( 
     select   invoice
     from     a_oe.oe_cust_orders
     where    category = 'APL'  )
order by invoice
; 


/*  Demo 27  */   
select   distinct 
         custid
,        invoice,category
from     a_oe.oe_cust_orders
where    Category <> 'APL' 
and      CustID  IN ( 
     select   custid
     from     a_oe.oe_cust_orders
     where    category = 'APL'  )
order by custid
; 

/*  Demo 28  */
select cust_id
,      cust_name_last
from   a_oe.customers
where  cust_id IN ( 
     select custID 
     from   a_oe.oe_cust_orders
     where  category = 'APL')
and      cust_id IN ( 
     select CustID 
     from   a_oe.oe_cust_orders
     where  Category = 'HW')
;

/*  Demo 29  */   
select distinct cust_id
,      cust_name_last
from   a_oe.customers  CS
join   a_oe.oe_cust_orders  CO on CS.cust_id = CO.CustID
where  category = 'APL' and category = 'HW';

/*  Demo 30  */   
select distinct cust_id
,      cust_name_last
from   a_oe.customers  CS
join   a_oe.oe_cust_orders  CO on CS.cust_id = CO.CustID
where  category = 'APL' or category = 'HW';

/*  Demo 31  */   
select distinct cust_id
,      cust_name_last
, category
, itempurchased
from   a_oe.customers  CS
join   a_oe.oe_cust_orders  CO on CS.cust_id = CO.CustID
where CustID = '401250';

select distinct cust_id
,      cust_name_last
, category
, itempurchased
from   a_oe.customers  CS
join   a_oe.oe_cust_orders  CO on CS.cust_id = CO.CustID
where CustID = '403000';
