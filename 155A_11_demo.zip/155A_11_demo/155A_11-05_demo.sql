create table zoo_ex (
  id integer primary key
, an_type varchar(15)
, an_price integer)
;

truncate table zoo_ex;
Insert into zoo_ex values
  (1,  'dog',    80)
, (2,  'turtle', NULL)
, (3,  'lizard', NULL)
, (4,  'bird',   100)
, (5,  'bird',   50)
, (6,  'fish',   10)
, (7,  'lizard', 50)
, (8,  'cat',    10)
, (9,  'snake',  50)
, (10, 'snake', NULL)
, (11, 'fish',  10)
, (12, 'lizard', 50)
, (13, 'fish',  10)
, (14, 'snake', 25)
, (15, 'bird',  80)
, (16, 'cat',   NULL)
, (17, 'bird',  80)
;


select * from zoo_ex
order by an_type, id;

-- Demo 01:	
select 'Found'
from dual
where exists (
  Select 1
  from zoo_ex)
  ;


-- Demo 02:	
select 'Found'
from dual
where exists (
  Select 1
  from zoo_ex
  where an_type='snake')
  ;


-- Demo 03:	
select 'Found'
from dual
where exists (
  Select 1
  from zoo_ex
  where an_type='penguin')
  ;

-- Demo 04:	
Select an_price
  from zoo_ex
  where an_type='snake'
  and an_price is null ;


-- Demo 05:	
select 'Found'
from dual
where exists (
  select an_price
  from zoo_ex
  where an_type='snake'
  and an_price is null)  ;


-- Demo 06:	
select 'Found'
from dual
where exists (
  select an_price
  from zoo_ex
  where an_type='bird'
  and an_price is null)
  ;


-- Demo 07:	
select *
from  zoo_ex
where an_type='bird'
and   exists (
  select 1
  from  zoo_ex
  where an_type='bird'
  and an_price < 75
  )
;

select *
from  zoo_ex
where an_type='bird'
and   exists (
  select 1
  from  zoo_ex
  where an_type='bird'
  and an_price < 15
  )
;



-- Demo 08:	
select *
from zoo_ex
where an_type='bird'
and  NOT exists (
  Select 1
  from zoo_ex
  where an_type='bird'
  and an_price < 75
  );


-- Demo 09:	
select *
from zoo_ex
where an_type='bird'
and  id in (
  Select id
  from zoo_ex
  where an_type='bird'
  and an_price < 75
  );


-- Demo 10:	
select *
from zoo_ex
where an_type='snake'
and  exists (
  Select 1
  from zoo_ex
  where an_type='snake'
  and an_price < 75  )
;

-- demo 10B: 
select *
from zoo_ex
where an_type='snake'
and  exists (
  Select 1
  from zoo_ex
  where an_type='snake'
  and an_price < 15
  )
;


-- Demo 11:	
select *
from zoo_ex
where an_type='snake'
and  NOT exists (
  Select 1
  from zoo_ex
  where an_type='snake'
  and an_price < 75
  )
;

-- Demo 11B:	 
select *
from zoo_ex
where an_type='snake'
and  NOT exists (
  Select 1
  from zoo_ex
  where an_type='snake'
  and an_price < 15
  )
;


-- Demo 12:	
select cust_id, cust_name_last, cust_name_first
from   a_oe.customers
where  EXISTS ( 
     select 'X' 
     from   a_oe.order_headers
     where  a_oe.order_headers.cust_id = a_oe.customers.cust_id
     and    extract( MONTH from ord_date) = 10  
     and    extract(Year from ord_date) = 2012)
;

-- Demo 13:	
select cust_id, cust_name_last, cust_name_first
from   a_oe.customers
where  cust_id in  ( 
     select cust_id 
     from   a_oe.order_headers
     where  extract(month from ord_date) = 10  
     and    extract(year from ord_date) = 2012 )
;

-- Demo 14:	 This query  may be less efficient  if there is a sort done to handle the distinct. 
select Distinct CS.cust_id, CS.cust_name_last, CS.cust_name_first
from   a_oe.customers CS
join   a_oe.order_headers  OH on  CS.cust_id =OH.cust_id
where  extract(month from ord_date) = 10  
and    extract(year from ord_date) = 2012 
;

-- Demo 15:	 This query can return multiple rows for the same customer.
select CS.cust_id, CS.cust_name_last, CS.cust_name_first
from   a_oe.customers CS
join   a_oe.order_headers  OH on  CS.cust_id =OH.cust_id
where  extract(month from ord_date) = 10  
and    extract(year from ord_date) = 2012
;

-- Demo 16:	
select cust_id
,      cust_name_last
,      cust_name_first
from   a_oe.customers
where  EXISTS ( 
     select 1 
     from  a_oe.order_headers OH
     join  a_oe.order_details OD on OH.ord_id =  OD.ord_id
     join  a_prd.products     PR on OD.prod_id = PR.prod_id
     where (prod_list_price - quoted_price)/prod_list_price > 0.1 
     and   a_oe.customers.cust_id = OH.cust_id)
order by cust_id;


-- Demo 17:	
select cust_id
,      cust_name_last
,      cust_name_first
from   a_oe.customers
where  NOT EXISTS ( 
     select 1 
     from  a_oe.order_headers OH
     join  a_oe.order_details OD on OH.ord_id =  OD.ord_id
     join  a_prd.products     PR on OD.prod_id = PR.prod_id
     where (prod_list_price - quoted_price)/prod_list_price > 0.1 
     and   a_oe.customers.cust_id = OH.cust_id)
order by cust_id
;


-- Demo 18:	

select   cust_id
,        cust_name_last
,        cust_name_first
from     a_oe.customers
where     EXISTS ( 
     select  1 
     from  a_oe.order_headers OH
     join  a_oe.order_details OD on OH.ord_id =  OD.ord_id
     join  a_prd.products     PR on OD.prod_id = PR.prod_id
     where not((prod_list_price - quoted_price)/prod_list_price > 0.1 )
     and   a_oe.customers.cust_id = OH.cust_id)
;

-- Demo 19:	
select   prod_id, prod_name
from   a_prd.products PR
where  EXISTS (
     select 'X' 
     from   a_oe.order_details OD
     where  PR.prod_id = OD.prod_id
     and    quantity_ordered >= 10) 
;


-- Demo 20:	
select a_oe.customers.cust_id
,      cust_name_last
from   a_oe.customers
where  EXISTS ( 
     select 'X'
     from   a_oe.cust_orders
     where  a_oe.cust_orders.custID = A_oe.customers.cust_id 
     and    category ='APL')
and   EXISTS ( 
     select 'X'
     from   a_oe.cust_orders
     where  a_oe.cust_orders.custID = A_oe.customers.cust_id 
     and    category ='HW')
;	


-- Demo 21:	
select CS.cust_id
,      CS.cust_name_last
, case when EXISTS (
   select 'X'
   from   a_oe.cust_orders
   where  a_oe.cust_orders.custID = CS.cust_id 
   and    category ='APL')  then 'Appliances  ' 
        else '    ---    ' End as " "
, case when EXISTS (
   select 'X'
   from   a_oe.cust_orders
   where  a_oe.cust_orders.custID = CS.cust_id 
   and    category ='HW')  then 'Housewares  ' 
        else '    ---    ' End   as " "   
, case when EXISTS (
   select 'X'
   from   a_oe.cust_orders
   where  a_oe.cust_orders.custID = CS.cust_id 
   and    category ='PET')  then 'PetSupplies '
        else '    ---    ' End   as " "
 From a_oe.customers  CS
;

-- Demo 22:	
select CS.cust_id
,      CS.cust_name_last
,   CONCAT(
 case when EXISTS (
   select 'X'
   from   a_oe.cust_orders
   where  a_oe.cust_orders.custID = CS.cust_id 
   and    category ='APL')  then 'Appliances  ' 
        else '' End
, case when EXISTS (
   select 'X'
   from   a_oe.cust_orders
   where  a_oe.cust_orders.custID = CS.cust_id 
   and    category ='HW')  then 'Housewares  ' 
        else '' End      
, case when EXISTS (
   select 'X'
   from   a_oe.cust_orders
   where  a_oe.cust_orders.custID = CS.cust_id 
   and    category ='PET')  then 'PetSupplies'
        else '' End   ) as PurchaseAreas 
 From a_oe.customers  CS;


-- Demo 23:	
create or replace   view a_oe.Ord as (
   select cust_id as CustID, prod_id  as prodid
   from a_oe.order_headers OH
   join a_oe.order_details OD  on OH.ord_id = OD.ord_id )

create or replace   view a_oe.SPG as (
   select prod_id  as spg_prod_id
   from a_prd.products   
   where catg_id = 'SPG' );
   
 
-- Demo 24:	
select Cust_id, cust_name_last
from a_oe.customers CS
where not exists 
   (select * 
    from a_oe.SPG
    where not exists 
       (select * 
	    from a_oe.ORD
        where a_oe.SPG.spg_prod_id = a_oe.Ord.prodid  
        and   a_oe.ord.custid = CS.cust_id) )
;   


Select prod_id, prod_name, catg_id 
from  a_prd.products   
where catg_id  = 'SPG';

select OH.cust_id, OD.prod_id, PR.prod_name, PR.catg_id 
from a_oe.order_headers OH
join a_oe.order_details OD  on OH.ord_id = OD.ord_id
join a_prd.products     PR on OD.prod_id = PR.prod_id
where cust_id in (403000, 408770)
and PR.catg_id  = 'SPG'
order by OH.cust_id, OD.prod_id
;

-- demo 25
select Cust_id, cust_name_last
from a_oe.customers CS
where not exists 
   (select * 
    from (
       select prod_id  as spg_prod_id
       from a_prd.products   
       where catg_id = 'SPG' ) tbl_S
    where not exists 
       (select * 
	    from (
           select cust_id as CustID, prod_id  as prodid
           from a_oe.order_headers OH
           join a_oe.order_details OD  on OH.ord_id = OD.ord_id ) tbl_o
        where tbl_S.spg_prod_id = tbl_o.prodid  
        and   tbl_o.custid = CS.cust_id) )
;  

-- Demo 26:	

select cust_id, cust_name_last
from (
   select CS.cust_id, CS.cust_name_last,PR.prod_id
   from   a_oe.customers CS
   join   a_oe.order_headers OH on CS.cust_id = OH.cust_id
   join   a_oe.order_details OD  on OH.ord_id = OD.ord_id 
   join   a_prd.products PR  on OD.prod_id = PR.prod_id
   where  catg_id = 'SPG') sales  
group by cust_id,cust_name_last
having count(distinct prod_id)
   = 
( select count(prod_id)
  from a_prd.products PR  
  where  catg_id = 'SPG'
)
;

-- Demo 27:	
select AllSales.cust_id, AllSales.cust_name_last
from   (
   select CS.cust_id, CS.cust_name_last,PR.prod_id, pr.catg_id
   from   a_oe.customers CS
   join   a_oe.order_headers OH on CS.cust_id = OH.cust_id
   join   a_oe.order_details OD  on OH.ord_id = OD.ord_id 
   join   a_prd.products PR  on OD.prod_id = PR.prod_id
   ) AllSales
join   
(
   select CS.cust_id, CS.cust_name_last,PR.prod_id, pr.catg_id
   from   a_oe.customers CS
   join   a_oe.order_headers OH on CS.cust_id = OH.cust_id
   join   a_oe.order_details OD  on OH.ord_id = OD.ord_id 
   join   a_prd.products PR  on OD.prod_id = PR.prod_id
   where  catg_id = 'SPG'
   ) spgSales on AllSales.cust_id = SPGSales.cust_id
cross join 
(
  select count(prod_id) as NumToys
  from a_prd.products PR  
  where  catg_id = 'SPG'
)ToyCount
group by AllSales.cust_id,AllSales.cust_name_last,ToyCount.NumToys 
having count(distinct spgSales.prod_id)
  = ToyCount.NumToys
and count(distinct allsales.prod_id)
  = ToyCount.NumToys
;


