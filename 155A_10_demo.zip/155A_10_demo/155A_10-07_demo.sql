 use a_testbed;

/*  Demo 01  */
select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
left join z_em_emp on z_em_dept.d_id = z_em_emp.d_id;

select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
right join z_em_emp on z_em_dept.d_id = z_em_emp.d_id;

/*  Demo 02  */	
select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
left join z_em_emp on z_em_dept.d_id = z_em_emp.d_id
union
select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
right join z_em_emp on z_em_dept.d_id = z_em_emp.d_id;


/*  Demo 03  */
select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
left join z_em_emp on z_em_dept.d_id = z_em_emp.d_id
union all
select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
right join z_em_emp on z_em_dept.d_id = z_em_emp.d_id;

select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
join z_em_emp on z_em_dept.d_id = z_em_emp.d_id;

/*  Demo 04  */
Select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
left join z_em_emp on z_em_dept.d_id = z_em_emp.d_id
union all
select z_em_dept.d_id, d_name, e_id, e_name
from z_em_dept 
right join z_em_emp on z_em_dept.d_id = z_em_emp.d_id
where z_em_dept.d_id is null;


