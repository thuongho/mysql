use a_testbed;

/*  Demo 01 */	
Create table a_testbed.z_group ( an_id integer primary key
, an_name varchar(15) not null
, an_type varchar(15) not null
, an_price integer not null);
Insert into a_testbed.z_group values 
(1, 'Max',  'dog', 500),    (2, 'Max',  'cat', 25),     
(3, 'Max',  'dog', 350),	 (4, 'Spot', 'dog', 400), 
(5, 'Spot', 'snake', 125),	 (6, 'Spot', 'dog', 400),
(7, 'Max',  'elephant', 75000);

select * 
from a_testbed.z_group;

/*  Demo 02 */	
select an_name, count(*)
from   a_testbed.z_group
group by an_name;


/*  Demo 03 */	
select an_name, an_type, an_price, count(*)
From   a_testbed.z_group
group by an_name;


/*  Demo 04 */	
select an_name, an_type, an_price, count(*)
from   a_testbed.z_group
group by an_name, an_type, an_price
;

/*  Demo 05 */	
select an_name,  max(an_price), count(*)
from a_testbed.z_group
group by an_name;

/*  Demo 06 */	
select   cust_id
,        ord_id
,        shipping_mode
,        count(*) AS "NumberLineItems"
from     a_oe.order_headers  inner join 
         a_oe.order_details using (ord_id)  
group by ord_id, cust_id, shipping_mode
order by cust_id, ord_id
;



/*  Demo 07 */	
select   cust_id
,        ord_id
,        shipping_mode
,        count(*) AS "NumberLineItems"
from     a_oe.order_headers  inner join 
         a_oe.order_details using (ord_id)  
group by ord_id
order by cust_id, ord_id
;

/*  Demo 08 */	
select   cust_id, cust_name_last, ord_id
,        ord_date
,        sum( quantity_ordered * quoted_price) as amntdue
from     a_oe.customers inner join 
         a_oe.order_headers  using (cust_id) inner join 
         a_oe.order_details using (ord_id)  
group by ord_id, cust_id, cust_name_last, ord_date
order by cust_id, ord_id
;


/*  Demo 09 */	
select   cust_id, cust_name_last, ord_id
,        ord_date
,        sum( quantity_ordered * quoted_price) as amntdue
from     a_oe.customers inner join 
         a_oe.order_headers  using (cust_id) inner join 
         a_oe.order_details using (ord_id)  
group by ord_id
order by cust_id, ord_id
;

/*  Demo 10 */	
select   cust_id, cust_name_last, ord_id
,        cast(ord_date as date) as OrderDate
,        sum( quantity_ordered * quoted_price) as amntdue
from     a_oe.customers inner join 
         a_oe.order_headers  using (cust_id) inner join 
         a_oe.order_details using (ord_id)  
group by ord_date
order by cust_id, ord_id
;

/*  Demo 11 */	
select   cust_id, cust_name_last, ord_id
,        cast(ord_date as date) as OrderDate
,        sum( quantity_ordered * quoted_price) as amntdue
from     a_oe.customers inner join 
         a_oe.order_headers  using (cust_id) inner join 
         a_oe.order_details using (ord_id)  
where ord_date = '2013-06-04'
group by ord_id  
order by cust_id, ord_id;

/*  Demo 12 */	
select   cust_id, cust_name_last, ord_id
,        cast(ord_date as date) as OrderDate
,        sum( quantity_ordered * quoted_price) as amntdue
from     a_oe.customers inner join 
         a_oe.order_headers  using (cust_id) inner join 
         a_oe.order_details using (ord_id)  
where ord_date = '2013-06-04'
group by  ord_date
order by cust_id, ord_id;

/*  Demo 13 */	
select   cast(ord_date as date) as OrderDate
        , count(*) as NumberOfOrders
,        sum( quantity_ordered * quoted_price) as amntdue
from     a_oe.order_headers  
join     a_oe.order_details using (ord_id)  
group by OrderDate
order by OrderDate
;


/*  Demo 14 */	
Select an_type, count(*), group_concat(an_name)
From   a_testbed.z_group
Group by an_type;

/*  Demo 15 */	
Select an_type, count(*), group_concat(distinct an_name)
From   a_testbed.z_group
Group by an_type;

/*  Demo 16 */	
Select an_type, count(*), group_concat(an_price order by an_price )
From   a_testbed.z_group
Group by an_type;

/*  Demo 17 */	
Select an_type, count(*), group_concat(concat(an_name, ' at $', an_price) )
From   a_testbed.z_group
Group by an_type;

/*  Demo 18 */
Select   left(ord_date, 10) as OrdDate
,        group_concat(prod_id order by prod_id) as ProductsSold
,        group_concat(distinct prod_id order by prod_id ) 
               as DistinctProductsSold
from     a_oe.customers inner join 
         a_oe.order_headers  using (cust_id) inner join 
         a_oe.order_details using (ord_id) 
where year(ord_date) = 2012
group by  ord_date
order by ord_date
;
