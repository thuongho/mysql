delimiter #

-- Demo 01:	
select 10000 as tstSalary from dual
union all 
select 30000  
union all 
select 50000#

-- demo 02
select tstSalary
from (
   select 10000 as tstSalary
   union all 
   select 30000
   union all 
   select 50000
) as testdata  #

-- Demo 03:	
Drop function if exists newsalary_3#

create function newsalary_3 (
   in_salary   decimal(9,2) )
   returns decimal (10,2)
begin
  declare  c_increase_rate	        decimal (4,3) default 0.10;
  declare  c_increase_amount	    decimal (8,2) default 3000;
  declare  v_using_rate 			decimal (8,2);
  declare  v_using_fixed_amount 	decimal (8,2);
  declare  v_new_salary  			decimal (8,2);

-- what would the value be with a 10% raise
   set v_using_rate:= in_salary * (1+ c_increase_rate);
-- what would the value be with a $3000 raise
   set v_using_fixed_amount:= in_salary + c_increase_amount;
-- take the bigger of those two values
   set v_new_salary := greatest(v_using_rate, v_using_fixed_amount);
   return v_new_salary ;
end;
#


-- Demo 04:	
select   emp_id, salary, dept_id, hire_date
,        NewSalary_3(salary) Sal_3  
from     a_emp.employees
order by salary
limit 5
#

-- Demo 05:	
select tstSalary , NewSalary_3(tstSalary) as "new salary"
from (
      select 10000 as tstSalary 
   union all    
      select 30000
   union all    
      select 50000) as testdata #

-- Demo 06:	
select tstSalary, AnticipatedValue, NewSalary_3(tstSalary) as "new salary"
from (
   select 10000 as tstSalary
        , 13000 as AnticipatedValue 
   union all   
   select 30000 
        , 33000
   union all
   select 50000
        , 55000) as testdata #

-- Demo 07:	
select 
  tstSalary
, AnticipatedValue
, NewSalary_3(tstSalary) as "new salary"
, AnticipatedValue - NewSalary_3(tstSalary) as "problem"
from (
   select 10000 as tstSalary
        , 13000 as AnticipatedValue 
   union all   
   select 30000 
        , 33000
   union all
   select 50000
        , 55000) as testdata #

-- Demo 08:	
Drop function if exists newsalary_4#

create function newsalary_4 (
   in_salary  decimal(9,2) )
   returns decimal (10,2)
begin
  declare  c_increase_rate      decimal (4,3) default 0.10;
  declare  c_increase_amount    decimal (10,2) default 3000;
  declare  v_new_salary          decimal (10,2);

   if ( in_salary  * c_increase_rate > c_increase_amount) then
      set v_new_salary := in_salary  * (1+ c_increase_rate);
   else
      set v_new_salary := in_salary  + c_increase_amount;
   end if;

   return v_new_salary ;
end;
#

-- Demo 09:	
select 
  tstSalary
, AnticipatedValue
, NewSalary_4(tstSalary) as "new salary"
, AnticipatedValue - NewSalary_4(tstSalary) as "problem"
from (
   select 10000 as tstSalary
        , 13000 as AnticipatedValue 
   union all   
   select 30000 
        , 33000
   union all
   select 50000
        , 55000) as testdata #

-- demo 10		
select 
  tstSalary
, AnticipatedValue
, CalcSalary
, AnticipatedValue - CalcSalary as "problem"
from (
   select   tstSalary
   , AnticipatedValue
   , NewSalary_4(tstSalary) as CalcSalary
   from (
      select 10000 as tstSalary
           , 13000 as AnticipatedValue 
      union all   
      select 30000, 33000
      union all
      select 50000, 55000
      ) as testdata 
	) as Calc  
#
		
		
		
		

-- Demo 11:	
   select 10000 as Salary
        ,    10 as dept_id
        , 10200 as AnticipatedValue 
   union all   
 select 10000,  20, 10250 
 union all 
 select 10000,  30, 10750
 union all 
 select 10000,  35, 10750
 union all 
 select 10000,  80, 10250
 union all 
 select 10000, 210, 10500
 union all 
 select 10000, 215, 10500
 union all
 select 10000,   1, 10250
#


-- Demo 12:	
Drop function if exists newsalary_5#

create function newsalary_5 (
   in_salary  decimal(9,2)
 , in_dept    int )
   returns decimal(10,2)
begin
  declare  v_increase_rate decimal(4,3);
  declare  v_new_salary    decimal(10,2);

   if (in_dept = 10 )then
     set v_increase_rate:= 0.02;
   elseif (in_dept = 30 or in_dept = 35 )then
      set v_increase_rate:= 0.075;
   elseif (in_dept in (210, 215) ) then
     set v_increase_rate:= 0.05;
   else
      set v_increase_rate:= 0.025;
   end if;

   set v_new_salary := in_salary  *(1+ v_increase_rate);
   return  v_new_salary;

end;
#


-- Demo 13:	
 select   emp_id, salary, dept_id, hire_date
 ,        NewSalary_5(salary, dept_id) Sal_5   
 from     a_emp.employees
limit  5
#


-- Demo 14:	
select 
  Salary
, dept_id
, AnticipatedValue
, NewSalary_5(salary, dept_id) as "new salary"
, AnticipatedValue - NewSalary_5(salary, dept_id) as "problem"
from (
    select 10000 as Salary
        ,    10 as dept_id
        , 10200 as AnticipatedValue 
  union all   
    select 10000,  20, 10250  
  union all  
    select 10000,  30, 10750
  union all  
    select 10000,  35, 10750
  union all  
    select 10000,  80, 10250
  union all  
    select 10000, 210, 10500
  union all  
    select 10000, 215, 10500
  union all
    select 10000,   1, 10250
 ) as tstTbl#

-- Demo 15:	
   select 10000        as Salary
        ,    10        as dept_id
        , '2011-01-15' as hire_date
        , 10000        as AnticipatedValue 
   union all 
   select 10000        
        ,    10        
        , '2010-01-15' 
        , 10200        
   union all   
   select 10000,  20, '2011-01-15', 10000   
   union all   
   select 10000,  20, '2010-01-15', 10250   
   union all   
   select 10000,  30, '2011-01-15', 10000
   union all    
   select 10000,  30, '2010-01-15', 10750
   union all   
   select 10000,  35, '2011-01-15', 10000
   union all   
   select 10000,  35, '2010-01-15', 10750
   union all   
   select 10000,  80, '2011-01-15', 10000
   union all   
   select 10000,  80, '2010-01-15', 10250
   union all   
   select 10000, 210, '2011-01-15', 10000
   union all   
   select 10000, 210, '2010-01-15', 10500
   union all   
   select 10000, 215, '2011-01-15', 10000
   union all   
   select 10000, 215, '2010-01-15', 10500
   union all
   select 10000,   1, '2011-01-15', 10000
   union all
   select 10000,   1, '2010-01-15', 10250
#


-- Demo 16:	
Drop function if exists newsalary_6#

create function newsalary_6 (
   in_salary     decimal(9,2)
 , in_dept      int
 , in_hire_date date )
   returns decimal (10,2)
begin
    declare  v_year_hired  decimal (4,0);
    declare  v_new_salary  decimal (10,2);

    set v_year_hired  := extract(year from in_hire_date);
    set v_new_salary := newsalary_5(in_salary, in_dept);
    if v_year_hired = extract(year from curdate()) 
    then
        set v_new_salary := in_salary;
    end if;
    return  v_new_salary;
end;
#


-- Demo 17:	
select 
  Salary
, dept_id
, hire_date
, AnticipatedValue
, NewSalary_6(salary, dept_id, hire_date) as "new salary"
, AnticipatedValue - NewSalary_6(salary, dept_id, hire_date) as "problem"
from (
   select 10000        as Salary
        ,    10        as dept_id
        , '2012-01-15' as hire_date
        , 10000        as AnticipatedValue 
   union all 
   select 10000,  10, '2010-01-15', 10200        
   union all   
   select 10000,  20, '2012-01-15', 10000   
   union all   
   select 10000,  20, '2010-01-15', 10250   
   union all   
   select 10000,  30, '2012-01-15', 10000
   union all    
   select 10000,  30, '2010-01-15', 10750
   union all   
   select 10000,  35, '2012-01-15', 10000
   union all   
   select 10000,  35, '2010-01-15', 10750
   union all   
   select 10000,  80, '2012-01-15', 10000
   union all   
   select 10000,  80, '2010-01-15', 10250
   union all   
   select 10000, 210, '2012-01-15', 10000
   union all   
   select 10000, 210, '2010-01-15', 10500
   union all   
   select 10000, 215, '2012-01-15', 10000
   union all   
   select 10000, 215, '2010-01-15', 10500
   union all
   select 10000,   1, '2012-01-15', 10000
   union all
   select 10000,   1, '2010-01-15', 10250
 ) as testdata #



-- Demo 18:	
select   emp_id, salary, dept_id, hire_date
,        NewSalary_6(salary, dept_id, hire_date)  Sal_6  
from     a_emp.employees
limit 5
#


-- Demo 19:	
Drop function if exists newsalary_5_V2#
create function newsalary_5_V2 (
   in_salary  decimal(9,2)
 , in_dept    int )
   returns decimal(10,2)
begin
  declare  v_increase_rate decimal (4,3);
  declare  v_new_salary    decimal(9,2);

  case in_dept
    when 10 then
       set v_increase_rate:= 0.02;
    when 30 then
        set v_increase_rate:= 0.075;
    when 35 then
       set v_increase_rate:= 0.075;
    when 210 then
       set v_increase_rate:= 0.05;
    when 215 then
       set v_increase_rate:= 0.05;
    else
        set v_increase_rate:= 0.025;
    end case;

  set v_new_salary := in_salary  *(1+ v_increase_rate);
  return  v_new_salary;
end;
#


-- Demo 20:	
select 
  Salary
, dept_id
, AnticipatedValue
, NewSalary_5_v2(salary, dept_id) as "new salary"
, AnticipatedValue - NewSalary_5_v2(salary, dept_id) as "problem"
from (
    select 10000 as Salary
        ,    10 as dept_id
        , 10200 as AnticipatedValue 
  union all   
    select 10000,  20, 10250  
  union all  
    select 10000,  30, 10750
  union all  
    select 10000,  35, 10750
  union all  
    select 10000,  80, 10250
  union all  
    select 10000, 210, 10500
  union all  
    select 10000, 215, 10500
  union all
    select 10000,   1, 10250
 ) as testdata #

