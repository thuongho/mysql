
-- demo 01
select   emp_id, name_last as "Employee"
from     a_emp.employees
where    dept_id = 
         (
          select  dept_id 
          from    a_emp.employees
          where   emp_id = 162
);

-- demo 02
select   emp_id 
,        name_last as "Employee"
from     a_emp.employees
where    dept_id = 
         (select  dept_id 
          from    a_emp.employees);

-- demo 03
select   emp_id 
,        name_last as "Employee"
from     a_emp.employees
where    dept_id =  
         (select  dept_id 
          from    a_emp.employees  
          Where name_last = 'Green'
          );

-- demo 04
 Set @catg := 'MUS';

select avg(prod_list_price)
from a_prd.products
where catg_id = @catg;

-- demo 05
select prod_id, prod_name, prod_list_price
from a_prd.products
where catg_id = @catg
and prod_list_price BETWEEN 
    (select 0.9 * avg(prod_list_price)
     from a_prd.products
     where catg_id = @catg)
AND 
   (select 1.1 * avg(prod_list_price)
    from a_prd.products
    where catg_id = @catg);

-- demo 06
select avg(salary) 
from a_emp.employees;



select emp_id,  name_last,
salary,
(select avg(salary) from a_emp.employees)  as MedSalary  
from a_emp.employees;

-- demo 07
select emp_id,name_last,
salary,
round(salary -(select avg(salary) from a_emp.employees),0)  as "Over/Under"
from a_emp.employees;



-- demo 08
select dept_id, emp_id,
  name_last,
  salary,
  round(salary -(select avg(salary) from a_emp.employees),0)  as "Over/Under"
from a_emp.employees
where dept_id in (30)
order by abs(salary -(select avg(salary) from a_emp.employees) )
;

-- demo 09
select   prod_id, prod_name, catg_id
,        prod_list_price - (select Round(avg(prod_list_price), 2)
           from a_prd.products  ) 
           as "Over/Under Avg Price"
from   a_prd.products  
order by catg_id
;

-- demo 10
select  cust_id,  ord_id
,  ( select sum(quantity_ordered) 
     from   a_oe.order_details  OD
   ) as "NumItems"
from  a_oe.order_headers  OH
limit 5
; 

-- demo 11
select 
   cust_id 
,  ord_id
,  ( select sum(quantity_ordered) 
     from   a_oe.order_details  OD
     where  OH.ord_id = OD.ord_id) as "NumItemsPerOrder"
from  a_oe.order_headers  OH
limit 10
; 

-- Demo 12	
select cust_id,ord_id 
,      coalesce( 
         ( select  SUM(quantity_ordered) 
           from    a_oe.order_details 
           where   a_oe.order_headers.ord_id= 
                   a_oe.order_details.ord_id)
           , 0) 
           as "NumitemsPerOrder"
from   a_oe.order_headers
order by NumItemsPerOrder
;

-- Demo 05:	
select   cust_id, ord_id 
,        SUM(quantity_ordered) AS NumItemsPerOrder
from     a_oe.order_headers  ORD
left join     a_oe.order_details ORDT using(ord_id)
group by cust_id, ord_id
order by NumItemsPerOrder
;


-- Demo 06:	
select  cust_id, ord_id
,      ( select   SUM(quantity_ordered) 
         from     a_oe.order_details 
         where    a_oe.order_headers.ord_id = 
                    a_oe.order_details.ord_id
       ) as "NumPerOrder"
,      ( select   SUM(quantity_ordered * quoted_price) 
         from     a_oe.order_details 
         where    a_oe.order_headers.ord_id = 
                  a_oe.order_details.ord_id
       ) as "OrderCost"
from    a_oe.order_headers
limit 8;

