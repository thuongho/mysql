use a_testbed;

-- Demo 01	
drop table if exists z_tst_auto;
create table z_tst_auto ( col_1 int, col_2 varchar(15))engine = Innodb;

set autocommit =1;
select @@autocommit;


insert into z_tst_auto values
(11, 'red'), (21, 'green'), (31, 'blue'),(41, 'yellow'), (51, 'black'), (61, 'ecru');

update z_tst_auto 
set col_2 = 'olive'
where col_1 in ( 31,51);

delete from z_tst_auto
where col_2 in ('green');

select * from z_tst_auto;

rollback;

select * from z_tst_auto;
-- Demo 02
set autocommit =0;
select @@autocommit;


insert into z_tst_auto values
(10, 'tomato'), (20, 'forest'), (30, 'cyan'),(40, 'orange'), (50, 'darkgray'), (60, 'cornsilk');

update z_tst_auto 
set col_2 = 'aliceblue'
where col_1 in ( 30,31,50, 51);

delete from z_tst_auto
where col_2 in ('forest','yellow' );

select * from z_tst_auto;

rollback;

select * from z_tst_auto;

-- demo 03
select @@autocommit;


insert into z_tst_auto values
(100, 'indigo'), (200, 'lawngreen'), (300, 'deepskyblue');
select * from z_tst_auto;
Commit;
select * from z_tst_auto;

rollback;

select * from z_tst_auto;

-- demo 04
select @@autocommit;


insert into z_tst_auto values
(400, 'LightCoral'), (500, 'DodgerBlue'), (600, 'Lavender');
select * from z_tst_auto;

create table z_tst_1 ( col1 int)engine = Innodb;
select * from z_tst_auto;

rollback;

select * from z_tst_auto;

-- demo 05
set autocommit =1;
select @@autocommit;




-- demo 06
drop table if exists z_tst_trans;

create table z_tst_trans ( col1 int, col2 varchar(15))engine = Innodb;

-- Demo 07	
begin;
insert into z_tst_trans values ( 1, 'hare'), ( 2, 'dragon');

select * from z_tst_trans;

rollback;
select * from z_tst_trans;



-- Demo 08
begin ;
insert into z_tst_trans values ( 3, 'snake'), ( 4, 'horse');

select * from z_tst_trans;

-- Do a commit - this makes the inserts persistent and ends the transaction
commit;  

-- Display the data in the table.
select * from z_tst_trans;



-- Demo 09	
begin ;
insert into z_tst_trans values ( 5, 'sheep'),( 6, 'monkey');

select * from z_tst_trans;

create table z_tst_2( col1 int)engine = Innodb;  

-- Display the data in the table.
select * from z_tst_trans;

rollback;
select * from z_tst_trans;

